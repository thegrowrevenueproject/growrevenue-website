/**
 * M365 Dispatcher - XHR Interceptor v3
 * Follows proven GrowMeOrganic interception pattern exactly:
 * - IIFE 1: Sales Navigator via onreadystatechange + responseType='text' at readyState 2
 * - IIFE 2: Regular LinkedIn via send addEventListener('load') + Blob handling
 * Both use postMessage + localStorage for maximum reliability
 */

// ═══ Helper Functions ═══════════════════════════════════════════════
function m365_cleanNameComma(s) { if (!s) return ''; return s.indexOf(',') > -1 ? s.split(',')[0] : s; }
function m365_cleanCompany(s) {
  if (!s) return '';
  return s.replace(/, Inc\./g,'').replace(/ Inc\./g,'').replace(/ Inc/g,'')
    .replace(/ LLC/g,'').replace(/, LLC/g,'').replace(/, INC\./g,'')
    .trim().replace(/<\/?b>/g,'').replace(/&lt;\/?b&gt;/g,'');
}
function m365_unescape(s) {
  if (!s) return '';
  var t = document.createElement('DIV'); t.innerHTML = s;
  return (t.textContent || t.innerText || '').replace(/<(?:.|\n)*?>/gm, '');
}
function m365_extractId(s) {
  if (!s) return '';
  return s.replace('urn:li:member:','').replace('urn:li:fs_salesProfile:','')
    .replace('urn:li:fs_miniProfile:','').replace(/[(),]/g,'').trim();
}
function m365_extractCompanyId(s) {
  if (!s) return '';
  return s.replace('urn:li:fs_salesCompany:','').replace('urn:li:fsd_company:','')
    .replace('urn:li:company:','').replace(/[(),]/g,'').trim();
}
function m365_companyFromHeadline(s) {
  if (!s) return '';
  var c = '';
  if (s.indexOf(' at ') !== -1) { c = s.split(' at '); c.shift(); c = c.join(' at '); }
  else if (s.indexOf(' @ ') !== -1) { c = s.split(' @ '); c.shift(); c = c.join(' @ '); }
  else if (s.indexOf('chez ') !== -1) { c = s.split('chez '); c.shift(); c = c.join('chez '); }
  if (!c) return '';
  if (c.indexOf('- ') !== -1) c = c.split('- ')[0];
  if (c.indexOf('| ') !== -1) c = c.split('| ')[0];
  return m365_cleanCompany(c.trim());
}
function m365_cleanUrl(s) {
  if (!s) return '';
  if (s.indexOf('?') !== -1) s = s.split('?')[0];
  return s;
}
function m365_splitName(s) {
  if (!s) return ['',''];
  s = s.trim();
  var parts = s.split(' ');
  if (parts.length === 0) return ['',''];
  if (parts.length === 1) return [parts[0], ''];
  return [parts[0], parts.slice(1).join(' ')];
}
function m365_emptyProfile() {
  return {
    linkedin_id:'', user_first_name:'', user_last_name:'', job_title:'',
    user_company_name:'', user_company_id:'', company_size:'', industry:'',
    user_city:'', user_url:'', user_profile_picture:'', user_number_connections:'',
    user_summary:'', user_source:'linkedin', email_first:'', email_second:'',
    phone:'', company_domain:'', domain:'', scraped_at: new Date().toISOString()
  };
}
function m365_send(profiles) {
  var keys = Object.keys(profiles);
  if (keys.length === 0) return;
  console.log('[M365 inject] Sending ' + keys.length + ' profiles');
  // Method 1: postMessage (primary)
  window.postMessage({ source: 'm365-dispatcher', type: 'SAVE_PROFILES', data: profiles }, '*');
  // Method 2: window variable (backup)
  try { window.__m365_backup_profiles = profiles; } catch(e) {}
}


// ═══════════════════════════════════════════════════════════════════
// IIFE 1: SALES NAVIGATOR INTERCEPTOR
// Uses onreadystatechange + responseType='text' at readyState 2
// ═══════════════════════════════════════════════════════════════════
if (window.location.href.indexOf('com/sales/') !== -1) {

  (function() {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function() {

      this.onreadystatechange = function(response) {

        if (response.currentTarget === undefined) return;
        if (response.currentTarget.responseURL === undefined) return;

        var urlRequested = response.currentTarget.responseURL;

        // ── Sales Nav Search Results ──
        if (urlRequested.indexOf('salesApiPeopleSearch') !== -1 ||
            urlRequested.indexOf('salesApiLeadSearch') !== -1) {

          if (this.readyState == 4 && this.status == 200) {
            try {
              var jsonProfiles = JSON.parse(this.responseText);
              var allProfiles = {};

              if (jsonProfiles['elements'] !== undefined) {
                jsonProfiles['elements'].forEach(function(v) {
                  var u = m365_emptyProfile();

                  // currentPositions as object (single position)
                  if (v['currentPositions'] !== undefined && v['currentPositions']['companyName'] !== undefined) {
                    u['user_company_name'] = m365_cleanCompany(v['currentPositions']['companyName']);
                  }
                  if (v['currentPositions'] !== undefined && v['currentPositions']['companyUrn'] !== undefined) {
                    u['user_company_id'] = m365_extractCompanyId(v['currentPositions']['companyUrn']);
                  }
                  if (v['currentPositions'] !== undefined && v['currentPositions']['title'] !== undefined) {
                    u['job_title'] = m365_unescape(v['currentPositions']['title']);
                  }

                  // currentPositions as array (multiple positions)
                  if (v['currentPositions'] !== undefined && v['currentPositions'].length > 0) {
                    for (var idx = 0; idx < v['currentPositions'].length; idx++) {
                      var el = v['currentPositions'][idx];
                      if (el['current'] === true) {
                        if (el['title']) u['job_title'] = m365_unescape(el['title']);
                        if (el['companyName']) u['user_company_name'] = m365_cleanCompany(el['companyName']);
                        if (el['companyUrn']) u['user_company_id'] = m365_extractCompanyId(el['companyUrn']);
                        break;
                      }
                      // If no current=true found, use first
                      if (idx === 0) {
                        if (el['title']) u['job_title'] = m365_unescape(el['title']);
                        if (el['companyName']) u['user_company_name'] = m365_cleanCompany(el['companyName']);
                        if (el['companyUrn']) u['user_company_id'] = m365_extractCompanyId(el['companyUrn']);
                      }
                    }
                  }

                  if (v['geoRegion']) u['user_city'] = v['geoRegion'];
                  if (v['firstName']) u['user_first_name'] = m365_cleanNameComma(v['firstName']);
                  if (v['lastName']) u['user_last_name'] = m365_cleanNameComma(v['lastName']);
                  if (v['objectUrn']) u['linkedin_id'] = m365_extractId(v['objectUrn']);
                  if (v['industry']) u['industry'] = v['industry'];
                  if (v['degree']) u['degree'] = v['degree'].toString().replace('FIRST_DEGREE','1').replace('SECOND_DEGREE','2').replace('THIRD_DEGREE','3');

                  if (v['entityUrn']) {
                    u['user_url'] = v['entityUrn'].toString()
                      .replace('urn:li:fs_salesProfile:(', 'https://www.linkedin.com/sales/people/')
                      .replace(',ibn_)', '').replace(')', '');
                  }

                  if (v['profilePictureDisplayImage'] && v['profilePictureDisplayImage']['artifacts']) {
                    var arts = v['profilePictureDisplayImage']['artifacts'];
                    if (arts.length > 0) {
                      var rootUrl = v['profilePictureDisplayImage']['rootUrl'] || '';
                      u['user_profile_picture'] = rootUrl + (arts[arts.length - 1]['fileIdentifyingUrlPathSegment'] || '');
                    }
                  }

                  if (u['linkedin_id'] !== '') {
                    allProfiles[u['linkedin_id']] = u;
                  }
                });
              }

              if (Object.keys(allProfiles).length > 0) {
                console.log('[M365 inject] Sales Nav search: ' + Object.keys(allProfiles).length + ' profiles');
                m365_send(allProfiles);
              }
            } catch(e) { console.log('[M365 inject] Sales search parse error:', e); }

          } else if (this.readyState == 2) {
            // CRITICAL: Force text response type so responseText is available
            try { this.responseType = "text"; } catch(e) {}
          }
        }

        // ── Sales Nav Single Profile ──
        if (urlRequested.indexOf('salesApiProfiles') !== -1) {
          if (this.readyState == 4 && this.status == 200) {
            try {
              var pj = JSON.parse(this.responseText);
              var all2 = {};
              var p2 = m365_emptyProfile();
              if (pj['firstName']) p2['user_first_name'] = m365_cleanNameComma(pj['firstName']);
              if (pj['lastName']) p2['user_last_name'] = m365_cleanNameComma(pj['lastName']);
              if (pj['headline']) p2['job_title'] = m365_unescape(pj['headline']);
              if (pj['geoRegion']) p2['user_city'] = pj['geoRegion'];
              if (pj['objectUrn']) p2['linkedin_id'] = m365_extractId(pj['objectUrn']);
              if (pj['industry']) p2['industry'] = pj['industry'];
              if (pj['summary']) p2['user_summary'] = pj['summary'];
              if (pj['currentPositions'] && pj['currentPositions'].length > 0) {
                var cp = pj['currentPositions'][0];
                if (cp['title']) p2['job_title'] = m365_unescape(cp['title']);
                if (cp['companyName']) p2['user_company_name'] = m365_cleanCompany(cp['companyName']);
                if (cp['companyUrn']) p2['user_company_id'] = m365_extractCompanyId(cp['companyUrn']);
              }
              if (pj['entityUrn']) {
                p2['user_url'] = pj['entityUrn'].toString()
                  .replace('urn:li:fs_salesProfile:(', 'https://www.linkedin.com/sales/people/')
                  .replace(',ibn_)', '').replace(')', '');
              }
              if (pj['contactInfo'] && pj['contactInfo']['emailAddress']) {
                p2['email_first'] = pj['contactInfo']['emailAddress'];
              }
              if (p2['linkedin_id']) { all2[p2['linkedin_id']] = p2; m365_send(all2); }
            } catch(e) {}
          } else if (this.readyState == 2) {
            try { this.responseType = "text"; } catch(e) {}
          }
        }
      };

      origOpen.apply(this, arguments);
    };
  })();

}


// ═══════════════════════════════════════════════════════════════════
// IIFE 2: REGULAR LINKEDIN INTERCEPTOR (Voyager API)
// Uses send + addEventListener('load') + Blob handling
// ═══════════════════════════════════════════════════════════════════
if (window.location.href.indexOf('linkedin.com') !== -1) {

  (function() {
    var XHR = XMLHttpRequest.prototype;
    var origOpen2 = XHR.open;
    var origSend2 = XHR.send;

    XHR.open = function(method, url) {
      this._m365_url = url;
      return origOpen2.apply(this, arguments);
    };

    XHR.send = function(postData) {
      this.addEventListener('load', function() {
        var urlRequested = this._m365_url ? this._m365_url.toLowerCase() : '';

        // Skip if on Sales Navigator (handled by IIFE 1)
        if (window.location.href.indexOf('com/sales/') !== -1) return;

        // Check for search endpoints
        if (urlRequested.indexOf('/voyager/api/search/blended') === -1 &&
            urlRequested.indexOf('/voyager/api/search/dash/clusters') === -1 &&
            urlRequested.indexOf('voyagersearchdashlazyloadedactions') === -1 &&
            urlRequested.indexOf('/voyager/api/graphql') === -1) {
          return;
        }

        var processText = function(text) {
          try {
            var jsonProfiles = JSON.parse(text);
            var allProfiles = {};

            // ── Blended Search ──
            if (urlRequested.indexOf('/voyager/api/search/blended') !== -1) {
              if (jsonProfiles['data'] && jsonProfiles['data']['elements'] &&
                  jsonProfiles['data']['elements'][0] && jsonProfiles['data']['elements'][0]['elements']) {
                jsonProfiles['data']['elements'][0]['elements'].forEach(function(v) {
                  var u = m365_emptyProfile();
                  if (v['snippetText'] && v['snippetText']['text']) {
                    u['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['snippetText']['text']));
                  }
                  if (!u['user_company_name'] && v['headline'] && v['headline']['text']) {
                    u['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['headline']['text']));
                  }
                  if (v['subline'] && v['subline']['text']) u['user_city'] = v['subline']['text'];
                  if (v['headline'] && v['headline']['text']) u['job_title'] = m365_unescape(v['headline']['text']);
                  if (v['title'] && v['title']['text']) {
                    var nm = m365_splitName(v['title']['text']);
                    u['user_first_name'] = m365_cleanNameComma(nm[0]);
                    u['user_last_name'] = m365_cleanNameComma(nm[1]);
                  }
                  if (v['trackingUrn']) u['linkedin_id'] = m365_extractId(v['trackingUrn']);
                  if (v['publicIdentifier']) u['user_url'] = 'https://linkedin.com/in/' + v['publicIdentifier'];
                  if (v['navigationUrl']) u['user_url'] = m365_cleanUrl(v['navigationUrl']);
                  if (u['linkedin_id'] !== '') allProfiles[u['linkedin_id']] = u;
                });
              }
            }

            // ── Dash Clusters / GraphQL / Lazy Loaded ──
            if (urlRequested.indexOf('/voyager/api/search/dash/clusters') !== -1 ||
                urlRequested.indexOf('voyagersearchdashlazyloadedactions') !== -1 ||
                urlRequested.indexOf('graphql') !== -1) {

              // Process included array
              if (jsonProfiles['included'] !== undefined) {
                jsonProfiles['included'].forEach(function(v) {

                  // Standard trackingUrn items
                  if (v['trackingUrn'] && v['trackingUrn'].indexOf('urn:li:member:') !== -1) {
                    var u = m365_emptyProfile();
                    if (v['summary'] && v['summary']['text']) {
                      u['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['summary']['text']));
                    }
                    if (!u['user_company_name'] && v['headline'] && v['headline']['text']) {
                      u['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['headline']['text']));
                    }
                    if (v['subline'] && v['subline']['text']) u['user_city'] = v['subline']['text'];
                    if (v['headline'] && v['headline']['text']) u['job_title'] = m365_unescape(v['headline']['text']);
                    if (v['title'] && v['title']['text']) {
                      var nm = m365_splitName(v['title']['text']);
                      u['user_first_name'] = m365_cleanNameComma(nm[0]);
                      u['user_last_name'] = m365_cleanNameComma(nm[1]);
                    }
                    if (v['trackingUrn']) u['linkedin_id'] = m365_extractId(v['trackingUrn']);
                    if (v['navigationUrl']) u['user_url'] = m365_cleanUrl(v['navigationUrl']);
                    if (u['linkedin_id'] !== '') allProfiles[u['linkedin_id']] = u;
                  }

                  // GraphQL UNIVERSAL template
                  if (v['template'] === 'UNIVERSAL') {
                    var u2 = m365_emptyProfile();
                    if (v['primarySubtitle'] && v['primarySubtitle']['text']) {
                      u2['job_title'] = m365_unescape(v['primarySubtitle']['text']);
                      u2['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['primarySubtitle']['text']));
                    }
                    if (v['title'] && v['title']['text']) {
                      var nm2 = m365_splitName(v['title']['text']);
                      u2['user_first_name'] = m365_cleanNameComma(nm2[0]);
                      u2['user_last_name'] = m365_cleanNameComma(nm2[1]);
                    }
                    if (v['trackingUrn']) u2['linkedin_id'] = m365_extractId(v['trackingUrn']);
                    if (v['navigationUrl']) u2['user_url'] = m365_cleanUrl(v['navigationUrl']);
                    if (v['secondarySubtitle'] && v['secondarySubtitle']['text']) {
                      u2['user_city'] = v['secondarySubtitle']['text'];
                    }
                    if (u2['linkedin_id'] !== '') allProfiles[u2['linkedin_id']] = u2;
                  }

                  // Anti-abuse metadata fallback
                  if (v['$anti_abuse_metadata'] && !v['trackingUrn']) {
                    var u3 = m365_emptyProfile();
                    if (v['headline']) u3['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['headline']));
                    if (v['firstName']) u3['user_first_name'] = m365_cleanNameComma(v['firstName']);
                    if (v['lastName']) u3['user_last_name'] = m365_cleanNameComma(v['lastName']);
                    if (v['publicIdentifier']) u3['user_url'] = 'https://linkedin.com/in/' + v['publicIdentifier'];
                    if (v['$anti_abuse_metadata']['/lastName'] &&
                        v['$anti_abuse_metadata']['/lastName']['sourceUrns'] &&
                        v['$anti_abuse_metadata']['/lastName']['sourceUrns']['com.linkedin.common.urn.MemberUrn']) {
                      u3['linkedin_id'] = m365_extractId(
                        v['$anti_abuse_metadata']['/lastName']['sourceUrns']['com.linkedin.common.urn.MemberUrn']
                      );
                    }
                    if (u3['linkedin_id'] !== '' && u3['user_first_name'] !== '') {
                      allProfiles[u3['linkedin_id']] = u3;
                    }
                  }
                });
              }

              // Process searchDashClustersByAll (newer LinkedIn format)
              if (jsonProfiles['data'] && jsonProfiles['data']['searchDashClustersByAll'] &&
                  jsonProfiles['data']['searchDashClustersByAll']['elements']) {
                jsonProfiles['data']['searchDashClustersByAll']['elements'].forEach(function(cluster) {
                  if (cluster['items']) {
                    cluster['items'].forEach(function(item) {
                      var v = (item['item'] && item['item']['entityResult']) ? item['item']['entityResult'] : null;
                      if (!v) return;
                      var u = m365_emptyProfile();
                      if (v['title'] && v['title']['text']) {
                        var nm3 = m365_splitName(v['title']['text']);
                        u['user_first_name'] = m365_cleanNameComma(nm3[0]);
                        u['user_last_name'] = m365_cleanNameComma(nm3[1]);
                      }
                      if (v['primarySubtitle'] && v['primarySubtitle']['text']) {
                        u['job_title'] = m365_unescape(v['primarySubtitle']['text']);
                        u['user_company_name'] = m365_cleanCompany(m365_companyFromHeadline(v['primarySubtitle']['text']));
                      }
                      if (v['secondarySubtitle'] && v['secondarySubtitle']['text']) {
                        u['user_city'] = v['secondarySubtitle']['text'];
                      }
                      if (v['navigationUrl']) u['user_url'] = m365_cleanUrl(v['navigationUrl']);
                      if (v['trackingUrn']) u['linkedin_id'] = m365_extractId(v['trackingUrn']);
                      if (u['linkedin_id'] !== '') allProfiles[u['linkedin_id']] = u;
                    });
                  }
                });
              }
            }

            // Direct elements array
            if (jsonProfiles['elements'] && !jsonProfiles['data']) {
              jsonProfiles['elements'].forEach(function(v) {
                if (!v['trackingUrn'] && !v['publicIdentifier']) return;
                var u = m365_emptyProfile();
                if (v['firstName']) u['user_first_name'] = m365_cleanNameComma(v['firstName']);
                if (v['lastName']) u['user_last_name'] = m365_cleanNameComma(v['lastName']);
                if (v['headline']) u['job_title'] = m365_unescape(v['headline']);
                if (v['trackingUrn']) u['linkedin_id'] = m365_extractId(v['trackingUrn']);
                if (v['publicIdentifier']) u['user_url'] = 'https://linkedin.com/in/' + v['publicIdentifier'];
                if (u['linkedin_id'] !== '') allProfiles[u['linkedin_id']] = u;
              });
            }

            if (Object.keys(allProfiles).length > 0) {
              console.log('[M365 inject] Regular LinkedIn: ' + Object.keys(allProfiles).length + ' profiles');
              m365_send(allProfiles);
            }
          } catch(e) { /* not JSON */ }
        };

        // Handle Blob or text response
        if (this.response instanceof Blob) {
          this.response.text().then(processText);
        } else if (typeof this.responseText === 'string' && this.responseText.length > 2) {
          processText(this.responseText);
        } else if (typeof this.response === 'string' && this.response.length > 2) {
          processText(this.response);
        }
      });

      return origSend2.apply(this, arguments);
    };
  })();

}

console.log('[M365 Dispatcher] XHR Interceptor v3 loaded (' + window.location.href.substring(0, 60) + '...)');


// ═══════════════════════════════════════════════════════════════════
// CONTACT INFO RPC — runs in MAIN world (page context) with cookies
// Content.js sends M365_FETCH_CONTACT, we call LinkedIn API and reply
// ═══════════════════════════════════════════════════════════════════

function m365_getCsrf() {
  var m = document.cookie.match(/JSESSIONID="?([^";]+)/);
  return m ? m[1] : '';
}

window.addEventListener('message', function(ev) {
  if (!ev.data || ev.data.source !== 'm365-dispatcher' || ev.data.type !== 'M365_FETCH_CONTACT') return;

  var profileId = ev.data.profileId || '';
  var profileUrl = ev.data.profileUrl || '';
  var requestId = ev.data.requestId || '';
  var csrf = m365_getCsrf();
  var result = { email: '', phone: '', websites: [] };

  console.log('[M365 inject] RPC received: ' + requestId + ' csrf=' + (csrf ? 'YES(' + csrf.substring(0,10) + '...)' : 'EMPTY') + ' profileId=' + profileId);

  if (!csrf) {
    console.log('[M365 inject] NO CSRF TOKEN — cannot call LinkedIn APIs');
    window.postMessage({ source: 'm365-dispatcher', type: 'M365_CONTACT_RESULT', requestId: requestId, result: result }, '*');
    return;
  }

  var done1 = false, done2 = false;

  function maybeSend() {
    if (done1 && done2) {
      console.log('[M365 inject] ContactInfo result for ' + requestId + ':', JSON.stringify(result));
      window.postMessage({ source: 'm365-dispatcher', type: 'M365_CONTACT_RESULT', requestId: requestId, result: result }, '*');
    }
  }

  // Call 1: Sales Nav API with contactInfo decoration (for Sales Nav URLs)
  if (profileId) {
    var xhr1 = new XMLHttpRequest();
    var apiUrl = 'https://www.linkedin.com/sales-api/salesApiProfiles/(profileId:' + profileId + ',authType:undefined,authToken:undefined)?decoration=%28entityUrn%2CobjectUrn%2CfirstName%2ClastName%2CfullName%2Cheadline%2CcontactInfo%2CflagshipProfileUrl%2Cpositions*%29';
    xhr1.open('GET', apiUrl, true);
    xhr1.setRequestHeader('csrf-token', csrf);
    xhr1.setRequestHeader('x-li-lang', 'en_US');
    xhr1.setRequestHeader('x-restli-protocol-version', '2.0.0');
    xhr1.timeout = 5000;
    xhr1.onload = function() {
      try {
        var data = JSON.parse(xhr1.responseText);
        console.log('[M365 inject] SalesAPI response for ' + requestId + ':', xhr1.status);
        if (data.contactInfo) {
          if (data.contactInfo.emailAddress && data.contactInfo.emailAddress.length > 0) {
            result.email = data.contactInfo.emailAddress;
          }
          if (data.contactInfo.phoneNumbers && data.contactInfo.phoneNumbers.length > 0) {
            result.phone = data.contactInfo.phoneNumbers[0].number || '';
          }
        }
        // Get regular LinkedIn URL but skip Voyager (returns 410 Gone)
        if (data.flagshipProfileUrl) {
          result.flagshipUrl = data.flagshipProfileUrl;
        }
        done2 = true;
      } catch(e) {
        console.log('[M365 inject] SalesAPI parse error:', e.message);
        done2 = true;
      }
      done1 = true;
      maybeSend();
    };
    xhr1.onerror = function() { console.log('[M365 inject] SalesAPI error'); done1 = true; done2 = true; maybeSend(); };
    xhr1.ontimeout = function() { console.log('[M365 inject] SalesAPI timeout'); done1 = true; done2 = true; maybeSend(); };
    xhr1.send();
  } else {
    done1 = true;
    done2 = true;
    maybeSend();
  }

  // Call 2: Voyager profileContactInfo (works for /in/ URLs, returns personal emails + phones)
  function callVoyager(url) {
    var slug = '';
    if (url.indexOf('/in/') !== -1) {
      slug = url.split('/in/')[1];
      if (slug) slug = slug.replace(/\//g, '').split('?')[0];
    }
    if (!slug) { done2 = true; maybeSend(); return; }

    var xhr2 = new XMLHttpRequest();
    xhr2.open('GET', 'https://www.linkedin.com/voyager/api/identity/profiles/' + slug + '/profileContactInfo', true);
    xhr2.setRequestHeader('csrf-token', csrf);
    xhr2.timeout = 5000;
    xhr2.onload = function() {
      try {
        var data2 = JSON.parse(xhr2.responseText);
        console.log('[M365 inject] Voyager contactInfo for ' + slug + ':', xhr2.status, JSON.stringify(data2).substring(0, 200));
        if (data2.emailAddress && data2.emailAddress.length > 0) {
          if (!result.email) result.email = data2.emailAddress;
          else if (data2.emailAddress !== result.email) result.email2 = data2.emailAddress;
        }
        if (data2.phoneNumbers && data2.phoneNumbers.length > 0 && !result.phone) {
          result.phone = data2.phoneNumbers[0].number || '';
        }
        if (data2.websites && data2.websites.length > 0) {
          for (var w = 0; w < data2.websites.length; w++) {
            if (data2.websites[w].url) result.websites.push(data2.websites[w].url);
          }
        }
      } catch(e) {
        console.log('[M365 inject] Voyager parse error:', e.message);
      }
      done2 = true;
      maybeSend();
    };
    xhr2.onerror = function() { console.log('[M365 inject] Voyager error'); done2 = true; maybeSend(); };
    xhr2.ontimeout = function() { console.log('[M365 inject] Voyager timeout'); done2 = true; maybeSend(); };
    xhr2.send();
  }
});
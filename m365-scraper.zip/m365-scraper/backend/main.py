"""
M365 Dispatcher — Email Enrichment Backend
FastAPI server that finds emails from name + company via:
1. Pattern generation (15+ common email formats)
2. Domain discovery (company website lookup)
3. SMTP verification (MX lookup + SMTP handshake)
4. Website scraping (find emails on /about, /contact, /team pages)
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from enricher import EmailEnricher
from cache import EnrichmentCache

# ─── Logging ───────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('enrichment.log')
    ]
)
logger = logging.getLogger(__name__)

# ─── App ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="M365 Dispatcher Enrichment API",
    description="Email enrichment backend for LinkedIn scraper",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Chrome extension needs wildcard
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

enricher = EmailEnricher()
cache = EnrichmentCache()

# ─── Models ────────────────────────────────────────────────────────────

class EnrichRequest(BaseModel):
    first_name: str
    last_name: str
    company_name: str
    company_domain: Optional[str] = ""
    linkedin_url: Optional[str] = ""
    api_keys: Optional[dict] = None

class EnrichResponse(BaseModel):
    email: Optional[str] = None
    email_second: Optional[str] = None
    phone: Optional[str] = None
    company_domain: Optional[str] = None
    company_phone: Optional[str] = None
    confidence: int = 0
    method: str = ""
    cached: bool = False

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "2.0.0"
    timestamp: str = ""
    cache_size: int = 0

# ─── Routes ────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="ok",
        version="2.0.0",
        timestamp=datetime.utcnow().isoformat(),
        cache_size=cache.size()
    )

@app.post("/enrich", response_model=EnrichResponse)
async def enrich_contact(req: EnrichRequest):
    """
    Find email for a person given their name and company.
    Pipeline: cache check → domain discovery → pattern guess → SMTP verify → website scrape
    """
    if not req.first_name or not req.company_name:
        raise HTTPException(status_code=400, detail="first_name and company_name are required")

    # Normalize inputs
    first = req.first_name.strip().lower()
    last = (req.last_name or "").strip().lower()
    company = req.company_name.strip()

    # Skip if last name is missing or just an initial
    if not last or len(last) <= 1:
        return EnrichResponse(method="no_last_name", cached=False)

    try:
        # Check cache
        cache_key = f"{first}:{last}:{company.lower()}"
        cached = cache.get(cache_key)
        if cached:
            logger.info(f"Cache hit: {first} {last} @ {company}")
            return EnrichResponse(**cached, cached=True)

        logger.info(f"Enriching: {first} {last} @ {company}")

        # Run enrichment pipeline with global timeout
        result = await asyncio.wait_for(
            enricher.enrich(
                first_name=first,
                last_name=last,
                company_name=company,
                company_domain=req.company_domain.strip() if req.company_domain else "",
                linkedin_url=req.linkedin_url.strip() if req.linkedin_url else "",
                api_keys=req.api_keys or {}
            ),
            timeout=60.0  # 60 second max per profile
        )

        # Cache the result
        cache.set(cache_key, result)

        logger.info(f"Result: {first} {last} @ {company} → {result.get('email', 'none')} ({result.get('method', 'none')})")

        return EnrichResponse(**result, cached=False)

    except asyncio.TimeoutError:
        logger.warning(f"Timeout: {first} {last} @ {company}")
        return EnrichResponse(method="timeout", cached=False)
    except Exception as e:
        logger.error(f"Error enriching {first} {last} @ {company}: {e}")
        return EnrichResponse(method="error", cached=False)


@app.post("/enrich/bulk")
async def enrich_bulk(contacts: list[EnrichRequest]):
    """Enrich multiple contacts IN PARALLEL. Max 25 per request, 5 concurrent."""
    if len(contacts) > 25:
        raise HTTPException(status_code=400, detail="Maximum 25 contacts per bulk request")

    CONCURRENCY = 5
    results = [None] * len(contacts)

    async def enrich_one(idx, contact):
        try:
            result = await enrich_contact(contact)
            results[idx] = result.dict()
        except Exception as e:
            results[idx] = {
                "email": None, "email_second": None, "phone": None,
                "company_domain": None, "company_phone": None,
                "confidence": 0, "method": "error", "cached": False,
                "error": str(e), "first_name": contact.first_name, "last_name": contact.last_name
            }

    # Process in chunks of CONCURRENCY
    for i in range(0, len(contacts), CONCURRENCY):
        chunk = contacts[i:i + CONCURRENCY]
        await asyncio.gather(*[
            enrich_one(i + j, contact) for j, contact in enumerate(chunk)
        ])

    return {"results": results, "total": len(results)}


@app.get("/cache/stats")
async def cache_stats():
    return {
        "size": cache.size(),
        "hits": cache.hits,
        "misses": cache.misses
    }


@app.get("/db/stats")
async def db_stats():
    """Stats from the persistent SQLite database."""
    return enricher.db.stats()


@app.delete("/cache/clear")
async def cache_clear():
    cache.clear()
    return {"status": "cleared"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

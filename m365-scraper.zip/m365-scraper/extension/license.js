/**
 * ColdPumper License Manager — Chrome Extension
 * 
 * 4 Layers of Anti-Abuse:
 *  Layer 1: Machine activation limit (machine_id binding)
 *  Layer 2: Deactivation cooldown (48h, backend-enforced)
 *  Layer 3: Usage telemetry (profiles, scrapes, cache size per heartbeat)
 *  Layer 4: LinkedIn account binding (reported on activation + heartbeat)
 *
 * Owner key bypass — unlimited, no server calls, no limits.
 */

const LICENSE_API = 'https://api.coldpumper.com';
const OWNER_KEY = 'CP-OWNER-GROWREVENUE-2026-UNLIMITED';
const OWNER_PWD = 'GrOwReVeNuE2026!';

// ─── Machine ID ──────────────────────────────────────────────────────

async function getMachineId() {
  var data = await chrome.storage.local.get('cp_machine_id');
  if (data.cp_machine_id) return data.cp_machine_id;
  var id = 'EX-' + crypto.randomUUID();
  await chrome.storage.local.set({ cp_machine_id: id });
  return id;
}

// ─── Owner Check ─────────────────────────────────────────────────────

async function isOwner() {
  var saved = await chrome.storage.local.get(['cp_license_key', 'cp_is_owner']);
  return saved.cp_license_key === OWNER_KEY && saved.cp_is_owner === true;
}

// ─── Usage Telemetry Helpers ─────────────────────────────────────────

async function getUsageTelemetry() {
  var data = await chrome.storage.local.get([
    'm365_lists', 'cp_contacts_scraped_today', 'cp_scrape_date', 'cp_linkedin_account'
  ]);

  // Count profiles and cache size from lists
  var lists = data.m365_lists || {};
  var profilesCount = 0;
  var cacheSize = 0;
  Object.keys(lists).forEach(function (name) {
    var profiles = lists[name].profiles || {};
    var count = Object.keys(profiles).length;
    profilesCount += count;
    cacheSize += count;
  });

  // Reset daily counter if new day
  var today = new Date().toISOString().slice(0, 10);
  var scrapedToday = 0;
  if (data.cp_scrape_date === today) {
    scrapedToday = data.cp_contacts_scraped_today || 0;
  } else {
    // New day — reset counter
    await chrome.storage.local.set({ cp_contacts_scraped_today: 0, cp_scrape_date: today });
  }

  return {
    profiles_count: profilesCount,
    contacts_scraped_today: scrapedToday,
    cache_size: cacheSize,
    linkedin_account: data.cp_linkedin_account || ''
  };
}

async function incrementDailyScrapeCount(count) {
  var data = await chrome.storage.local.get(['cp_contacts_scraped_today', 'cp_scrape_date']);
  var today = new Date().toISOString().slice(0, 10);
  var current = 0;
  if (data.cp_scrape_date === today) {
    current = data.cp_contacts_scraped_today || 0;
  }
  await chrome.storage.local.set({
    cp_contacts_scraped_today: current + count,
    cp_scrape_date: today
  });
}

async function setLinkedInAccount(url) {
  if (url && url.indexOf('linkedin.com/in/') !== -1) {
    await chrome.storage.local.set({ cp_linkedin_account: url });
  }
}

async function getDailyScrapedCount() {
  var data = await chrome.storage.local.get(['cp_contacts_scraped_today', 'cp_scrape_date']);
  var today = new Date().toISOString().slice(0, 10);
  if (data.cp_scrape_date === today) {
    return data.cp_contacts_scraped_today || 0;
  }
  return 0;
}

// ─── License Verification ────────────────────────────────────────────

async function verifyLicense(key, password, email) {
  // Owner key bypass — no server call, unlimited everything
  if (key.trim() === OWNER_KEY && password.trim() === OWNER_PWD) {
    await chrome.storage.local.set({
      cp_license_key: OWNER_KEY,
      cp_password: OWNER_PWD,
      cp_email: email,
      cp_plan: 'unlimited',
      cp_status: 'active',
      cp_customer_name: 'Owner',
      cp_activations_used: 1,
      cp_activations_max: 999,
      cp_features: _ownerFeatures(),
      cp_license_valid: true,
      cp_last_verified: Date.now(),
      cp_is_owner: true
    });
    return { success: true, plan: 'unlimited', status: 'active', name: 'Owner', features: _ownerFeatures() };
  }

  // Regular license — server verification with Layer 4 account binding
  var machineId = await getMachineId();
  var telemetry = await getUsageTelemetry();

  try {
    var resp = await fetch(LICENSE_API + '/api/verify-license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        license_key: key,
        password: password,
        machine_id: machineId,
        product_type: 'chrome_extension',
        email: email,
        linkedin_account: telemetry.linkedin_account
      })
    });
    var data = await resp.json();

    if (data.status === 'active' || data.status === 'trial') {
      await chrome.storage.local.set({
        cp_license_key: key,
        cp_password: password,
        cp_email: email,
        cp_plan: data.plan_tier,
        cp_status: data.status,
        cp_customer_name: data.customer_name || '',
        cp_activations_used: data.activations_used || 0,
        cp_activations_max: data.activations_max || 2,
        cp_features: data.features || {},
        cp_license_valid: true,
        cp_last_verified: Date.now(),
        cp_is_owner: false
      });
      return {
        success: true,
        plan: data.plan_tier,
        status: data.status,
        name: data.customer_name,
        features: data.features
      };
    }

    return { success: false, error: data.error || 'License not active' };
  } catch (e) {
    return { success: false, error: 'Could not reach license server: ' + e.message };
  }
}

// ─── Heartbeat with Telemetry (Layer 3 + 4) ─────────────────────────

async function checkLicenseStatus() {
  // Owner — always valid, skip everything
  if (await isOwner()) return true;

  var data = await chrome.storage.local.get([
    'cp_license_key', 'cp_machine_id', 'cp_license_valid', 'cp_last_verified'
  ]);

  if (!data.cp_license_key) return false;

  var machineId = data.cp_machine_id || await getMachineId();
  var telemetry = await getUsageTelemetry();

  try {
    var resp = await fetch(LICENSE_API + '/api/license-status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        license_key: data.cp_license_key,
        machine_id: machineId,
        product_type: 'chrome_extension',
        profiles_count: telemetry.profiles_count,
        contacts_scraped_today: telemetry.contacts_scraped_today,
        cache_size: telemetry.cache_size,
        linkedin_account: telemetry.linkedin_account
      })
    });
    var result = await resp.json();

    if (result.status === 'active' || result.status === 'trial') {
      await chrome.storage.local.set({
        cp_license_valid: true,
        cp_last_verified: Date.now(),
        cp_status: result.status,
        cp_plan: result.plan_tier,
        cp_features: result.features || {}
      });
      return true;
    } else {
      await chrome.storage.local.set({ cp_license_valid: false, cp_status: result.status || 'invalid' });
      return false;
    }
  } catch (e) {
    // Offline — check grace period (7 days)
    var lastVerified = data.cp_last_verified || 0;
    var graceMs = 7 * 24 * 60 * 60 * 1000;

    if (Date.now() - lastVerified > graceMs) {
      await chrome.storage.local.set({ cp_license_valid: false });
      return false;
    }
    return data.cp_license_valid === true;
  }
}

// ─── Is Licensed ─────────────────────────────────────────────────────

async function isLicensed() {
  var data = await chrome.storage.local.get(['cp_license_valid', 'cp_license_key', 'cp_is_owner']);
  if (data.cp_license_key === OWNER_KEY && data.cp_is_owner === true) return true;
  return data.cp_license_valid === true && !!data.cp_license_key;
}

// ─── Get License Info ────────────────────────────────────────────────

async function getLicenseInfo() {
  var data = await chrome.storage.local.get([
    'cp_license_key', 'cp_email', 'cp_plan', 'cp_status',
    'cp_customer_name', 'cp_activations_used', 'cp_activations_max',
    'cp_features', 'cp_license_valid', 'cp_last_verified', 'cp_is_owner',
    'cp_contacts_scraped_today', 'cp_linkedin_account'
  ]);
  return data;
}

// ─── Deactivate License (Layer 2: 48h cooldown enforced by backend) ──

async function deactivateLicense() {
  var data = await chrome.storage.local.get(['cp_license_key', 'cp_password', 'cp_machine_id', 'cp_is_owner']);
  if (!data.cp_license_key) return { success: false, error: 'No license to deactivate' };

  // Owner — just clear local, no server
  if (data.cp_is_owner) {
    await _clearLicenseData();
    return { success: true };
  }

  // Regular — server enforces 48h cooldown (Layer 2)
  try {
    var resp = await fetch(LICENSE_API + '/api/deactivate-license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        license_key: data.cp_license_key,
        password: data.cp_password,
        machine_id: data.cp_machine_id,
        product_type: 'chrome_extension'
      })
    });
    var result = await resp.json();

    // Backend may reject if within 48h cooldown
    if (result.error) {
      return { success: false, error: result.error };
    }
  } catch (e) {
    // Deactivate locally even if server fails
  }

  await _clearLicenseData();
  return { success: true };
}

async function _clearLicenseData() {
  await chrome.storage.local.remove([
    'cp_license_key', 'cp_password', 'cp_email', 'cp_plan',
    'cp_status', 'cp_customer_name', 'cp_activations_used',
    'cp_activations_max', 'cp_features', 'cp_license_valid',
    'cp_last_verified', 'cp_is_owner', 'cp_contacts_scraped_today',
    'cp_scrape_date', 'cp_linkedin_account'
  ]);
}

// ─── Owner Features ──────────────────────────────────────────────────

function _ownerFeatures() {
  return {
    max_emails_per_day: 999999,
    max_profiles_per_day: 999999,
    shared_mailbox_rotation: true,
    spintax_engine: true,
    ab_testing: true,
    linkedin_extractor: true,
    external_providers: true,
    multi_step_sequences: true,
    email_verification: true
  };
}

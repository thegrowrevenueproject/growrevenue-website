"""
M365 Dispatcher - Email Enrichment Engine v6

IMPROVEMENTS:
- Personal email SMTP verification (hotmail/yahoo/outlook patterns)
- Better domain discovery (Clearbit + slug + company name variations)
- Persistent SQLite database for long-term caching (ready for Apollo)
- All emails SMTP-verified before returning
"""

import asyncio
import logging
import re
import sqlite3
import time
import json
from typing import Optional

import aiosmtplib
import dns.resolver
import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

SMTP_TIMEOUT = 8
HTTP_TIMEOUT = 10
DNS_TIMEOUT = 5

GENERIC_PREFIXES = {
    'info', 'contact', 'support', 'admin', 'hello', 'sales', 'help',
    'office', 'mail', 'noreply', 'no-reply', 'webmaster', 'team',
    'hr', 'jobs', 'careers', 'press', 'media', 'marketing',
    'billing', 'accounts', 'legal', 'compliance', 'privacy',
    'abuse', 'postmaster', 'security', 'feedback', 'inquiries',
    'general', 'reception', 'service', 'solutions', 'invest',
    'partnerships', 'events', 'newsletter', 'subscribe',
    'clientinfo', 'distribution',
}

# Personal email domains where SMTP verification works
VERIFIABLE_PERSONAL_DOMAINS = [
    'hotmail.com', 'outlook.com', 'live.com', 'msn.com',
    'yahoo.com', 'ymail.com',
    'aol.com',
    'mail.com',
    'protonmail.com',
]


class PersistentDB:
    """SQLite database for permanent email cache — survives restarts."""

    def __init__(self, db_path="/opt/m365-api/email_cache.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS email_cache (
                    lookup_key TEXT PRIMARY KEY,
                    first_name TEXT,
                    last_name TEXT,
                    company_name TEXT,
                    email TEXT,
                    email_second TEXT,
                    phone TEXT,
                    company_domain TEXT,
                    confidence INTEGER DEFAULT 0,
                    method TEXT,
                    source TEXT DEFAULT 'smtp',
                    raw_json TEXT,
                    created_at REAL,
                    updated_at REAL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_email ON email_cache(email)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_domain ON email_cache(company_domain)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS domain_cache (
                    company_name_lower TEXT PRIMARY KEY,
                    domain TEXT,
                    created_at REAL
                )
            """)
            conn.commit()
            conn.close()
            logger.info(f"Persistent DB initialized: {self.db_path}")
        except Exception as e:
            logger.error(f"DB init error: {e}")

    def get(self, first, last, company):
        try:
            key = f"{first.lower()}:{last.lower()}:{company.lower()}"
            conn = sqlite3.connect(self.db_path)
            row = conn.execute(
                "SELECT raw_json FROM email_cache WHERE lookup_key = ?", (key,)
            ).fetchone()
            conn.close()
            if row:
                return json.loads(row[0])
        except Exception as e:
            logger.debug(f"DB get error: {e}")
        return None

    def save(self, first, last, company, result, source="smtp"):
        try:
            key = f"{first.lower()}:{last.lower()}:{company.lower()}"
            now = time.time()
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                INSERT OR REPLACE INTO email_cache
                (lookup_key, first_name, last_name, company_name,
                 email, email_second, phone, company_domain,
                 confidence, method, source, raw_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                key, first.lower(), last.lower(), company.lower(),
                result.get("email"), result.get("email_second"),
                result.get("phone"), result.get("company_domain"),
                result.get("confidence", 0), result.get("method", ""),
                source, json.dumps(result), now, now
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"DB save error: {e}")

    def get_domain(self, company_name):
        try:
            conn = sqlite3.connect(self.db_path)
            row = conn.execute(
                "SELECT domain FROM domain_cache WHERE company_name_lower = ?",
                (company_name.lower(),)
            ).fetchone()
            conn.close()
            return row[0] if row else None
        except Exception:
            return None

    def save_domain(self, company_name, domain):
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute(
                "INSERT OR REPLACE INTO domain_cache (company_name_lower, domain, created_at) VALUES (?, ?, ?)",
                (company_name.lower(), domain, time.time())
            )
            conn.commit()
            conn.close()
        except Exception:
            pass

    def stats(self):
        try:
            conn = sqlite3.connect(self.db_path)
            total = conn.execute("SELECT COUNT(*) FROM email_cache").fetchone()[0]
            with_email = conn.execute("SELECT COUNT(*) FROM email_cache WHERE email IS NOT NULL").fetchone()[0]
            domains = conn.execute("SELECT COUNT(*) FROM domain_cache").fetchone()[0]
            by_source = {}
            for row in conn.execute("SELECT source, COUNT(*) FROM email_cache GROUP BY source"):
                by_source[row[0]] = row[1]
            conn.close()
            return {"total": total, "with_email": with_email, "domains": domains, "by_source": by_source}
        except Exception:
            return {"total": 0, "with_email": 0, "domains": 0, "by_source": {}}


class EmailEnricher:

    def __init__(self):
        self.http_client = httpx.AsyncClient(
            timeout=HTTP_TIMEOUT,
            follow_redirects=True,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
        )
        self.db = PersistentDB()

    async def enrich(self, first_name, last_name, company_name, company_domain="", linkedin_url="", api_keys=None):
        result = {
            "email": None, "email_second": None, "phone": None,
            "company_domain": None, "company_phone": None,
            "confidence": 0, "method": ""
        }
        if api_keys is None:
            api_keys = {}

        try:
            # --- Check persistent DB first ---
            cached = self.db.get(first_name, last_name, company_name)
            if cached and cached.get("confidence", 0) > 0:
                logger.info(f"DB hit: {first_name} {last_name} -> {cached.get('email')}")
                return cached

            # --- Step 1: Domain Discovery (with DB cache) ---
            domain = company_domain
            if not domain:
                domain = self.db.get_domain(company_name)
            if not domain:
                domain = await self.discover_domain(company_name)
                if domain:
                    self.db.save_domain(company_name, domain)

            if not domain:
                # No corporate domain — try API providers, then personal emails
                api_result = await self._try_api_providers(
                    first_name, last_name, company_name, "", api_keys
                )
                if api_result:
                    self.db.save(first_name, last_name, company_name, api_result, source=api_result.get("method", "api"))
                    return api_result

                try:
                    personal = await asyncio.wait_for(
                        self.verify_personal_emails(first_name, last_name),
                        timeout=30.0
                    )
                except Exception:
                    personal = []

                if personal:
                    result["email"] = personal[0]
                    result["confidence"] = 80
                    result["method"] = "personal_smtp_verified"
                    if len(personal) > 1:
                        result["email_second"] = personal[1]
                    self.db.save(first_name, last_name, company_name, result)
                    return result

                result["method"] = "no_domain"
                self.db.save(first_name, last_name, company_name, result)
                return result

            result["company_domain"] = domain

            # --- Step 2: Catch-all Check ---
            try:
                is_catchall = await self.check_catchall(domain)
            except Exception:
                is_catchall = False

            # --- Step 3: Generate ALL corporate patterns ---
            patterns = self.generate_exhaustive_patterns(first_name, last_name, domain)
            if not patterns:
                result["method"] = "no_patterns"
                return result

            if is_catchall:
                result["email"] = patterns[0]
                result["email_second"] = patterns[1] if len(patterns) > 1 else None
                result["confidence"] = 30
                result["method"] = "catchall_pattern"
                self.db.save(first_name, last_name, company_name, result)
                return result

            # --- Step 4: SMTP verify ALL corporate patterns ---
            try:
                verified = await asyncio.wait_for(
                    self.verify_all_patterns(patterns, domain),
                    timeout=45.0
                )
            except asyncio.TimeoutError:
                logger.warning(f"SMTP timeout for {first_name} {last_name} @ {domain}")
                verified = []
            except Exception as e:
                logger.warning(f"SMTP error for {domain}: {e}")
                verified = []

            if verified:
                result["email"] = verified[0]
                result["confidence"] = 95
                result["method"] = "smtp_verified"
                if len(verified) > 1:
                    result["email_second"] = verified[1]
                self.db.save(first_name, last_name, company_name, result)
                return result

            # --- Step 5: Website scrape fallback ---
            try:
                scraped = await asyncio.wait_for(
                    self.scrape_website_emails(domain, first_name, last_name),
                    timeout=15.0
                )
            except Exception:
                scraped = []

            if scraped:
                result["email"] = scraped[0]
                result["confidence"] = 60
                result["method"] = "website_scrape"
                if len(scraped) > 1:
                    result["email_second"] = scraped[1]
                self.db.save(first_name, last_name, company_name, result)
                return result

            # --- Step 6: Third-party API providers ---
            api_result = await self._try_api_providers(
                first_name, last_name, company_name, domain, api_keys
            )
            if api_result:
                api_result["company_domain"] = domain
                self.db.save(first_name, last_name, company_name, api_result, source=api_result.get("method", "api"))
                return api_result

            # --- Step 7: Personal email SMTP verification ---
            try:
                personal = await asyncio.wait_for(
                    self.verify_personal_emails(first_name, last_name),
                    timeout=30.0
                )
            except Exception:
                personal = []

            if personal:
                result["email"] = personal[0]
                result["confidence"] = 80
                result["method"] = "personal_smtp_verified"
                result["company_domain"] = domain
                if len(personal) > 1:
                    result["email_second"] = personal[1]
                self.db.save(first_name, last_name, company_name, result)
                return result

            result["method"] = "not_found"
            result["confidence"] = 0
            result["company_domain"] = domain
            self.db.save(first_name, last_name, company_name, result)
            return result

        except Exception as e:
            logger.error(f"Enrichment failed for {first_name} {last_name}: {e}")
            result["method"] = "error"
            return result

    # --- Third-Party API Providers ---

    async def _try_api_providers(self, first_name, last_name, company_name, domain, api_keys):
        """Try each configured API provider in order. Returns result dict or None."""
        if not api_keys:
            return None

        # Try providers in order of best coverage
        providers = [
            ("apollo", self._lookup_apollo),
            ("hunter", self._lookup_hunter),
            ("snov", self._lookup_snov),
            ("rocketreach", self._lookup_rocketreach),
        ]

        for provider_name, lookup_fn in providers:
            key = api_keys.get(provider_name, "").strip()
            if not key:
                continue
            try:
                result = await asyncio.wait_for(
                    lookup_fn(first_name, last_name, company_name, domain, key),
                    timeout=15.0
                )
                if result and result.get("email"):
                    logger.info(f"{provider_name}: {first_name} {last_name} -> {result['email']}")
                    return result
            except Exception as e:
                logger.warning(f"{provider_name} error: {e}")
                continue

        return None

    async def _lookup_apollo(self, first_name, last_name, company_name, domain, api_key):
        """Apollo.io People Enrichment API."""
        try:
            payload = {
                "first_name": first_name,
                "last_name": last_name,
                "organization_name": company_name,
            }
            if domain:
                payload["domain"] = domain

            resp = await self.http_client.post(
                "https://api.apollo.io/v1/people/match",
                json=payload,
                headers={"Content-Type": "application/json", "Cache-Control": "no-cache"},
                params={"api_key": api_key}
            )
            if resp.status_code != 200:
                logger.debug(f"Apollo API {resp.status_code}: {resp.text[:200]}")
                return None

            data = resp.json()
            person = data.get("person") or data
            email = person.get("email")
            if not email:
                return None

            return {
                "email": email,
                "email_second": None,
                "phone": person.get("phone_number"),
                "company_domain": person.get("organization", {}).get("primary_domain") or domain,
                "company_phone": person.get("organization", {}).get("phone"),
                "confidence": 85,
                "method": "apollo_api"
            }
        except Exception as e:
            logger.debug(f"Apollo lookup failed: {e}")
            return None

    async def _lookup_hunter(self, first_name, last_name, company_name, domain, api_key):
        """Hunter.io Email Finder API."""
        if not domain:
            return None
        try:
            resp = await self.http_client.get(
                "https://api.hunter.io/v2/email-finder",
                params={
                    "domain": domain,
                    "first_name": first_name,
                    "last_name": last_name,
                    "api_key": api_key
                }
            )
            if resp.status_code != 200:
                logger.debug(f"Hunter API {resp.status_code}: {resp.text[:200]}")
                return None

            data = resp.json().get("data", {})
            email = data.get("email")
            if not email:
                return None

            score = data.get("score", 0)
            return {
                "email": email,
                "email_second": None,
                "phone": None,
                "company_domain": domain,
                "company_phone": None,
                "confidence": min(score, 95),
                "method": "hunter_api"
            }
        except Exception as e:
            logger.debug(f"Hunter lookup failed: {e}")
            return None

    async def _lookup_snov(self, first_name, last_name, company_name, domain, api_key):
        """Snov.io Email Finder API. api_key format: 'user_id:secret'"""
        if not domain:
            return None
        try:
            parts = api_key.split(":", 1)
            if len(parts) != 2:
                logger.debug("Snov key format should be 'user_id:secret'")
                return None
            user_id, secret = parts

            # Step 1: Get access token
            token_resp = await self.http_client.post(
                "https://api.snov.io/v1/oauth/access_token",
                json={"grant_type": "client_credentials", "client_id": user_id, "client_secret": secret}
            )
            if token_resp.status_code != 200:
                return None
            token = token_resp.json().get("access_token")
            if not token:
                return None

            # Step 2: Find email
            resp = await self.http_client.post(
                "https://api.snov.io/v1/get-emails-from-names",
                json={
                    "firstName": first_name,
                    "lastName": last_name,
                    "domain": domain,
                    "access_token": token
                }
            )
            if resp.status_code != 200:
                return None

            data = resp.json()
            emails = data.get("data", {}).get("emails", [])
            if not emails:
                return None

            best = emails[0]
            return {
                "email": best.get("email"),
                "email_second": emails[1].get("email") if len(emails) > 1 else None,
                "phone": None,
                "company_domain": domain,
                "company_phone": None,
                "confidence": 80,
                "method": "snov_api"
            }
        except Exception as e:
            logger.debug(f"Snov lookup failed: {e}")
            return None

    async def _lookup_rocketreach(self, first_name, last_name, company_name, domain, api_key):
        """RocketReach Person Lookup API."""
        try:
            params = {
                "name": f"{first_name} {last_name}",
                "current_employer": company_name,
            }

            resp = await self.http_client.get(
                "https://api.rocketreach.co/api/v2/person/lookup",
                params=params,
                headers={"Api-Key": api_key}
            )
            if resp.status_code != 200:
                logger.debug(f"RocketReach API {resp.status_code}: {resp.text[:200]}")
                return None

            data = resp.json()
            emails = data.get("emails", [])
            if not emails:
                return None

            # RocketReach returns emails with types
            primary = None
            secondary = None
            for e in emails:
                email_addr = e if isinstance(e, str) else e.get("email", "")
                if email_addr:
                    if not primary:
                        primary = email_addr
                    elif not secondary:
                        secondary = email_addr

            if not primary:
                return None

            return {
                "email": primary,
                "email_second": secondary,
                "phone": None,
                "company_domain": domain,
                "company_phone": None,
                "confidence": 85,
                "method": "rocketreach_api"
            }
        except Exception as e:
            logger.debug(f"RocketReach lookup failed: {e}")
            return None

    # --- Personal Email Verification ---

    def generate_personal_patterns(self, first, last):
        f = re.sub(r'[^a-z]', '', first.lower().strip())
        l = re.sub(r'[^a-z]', '', last.lower().strip())
        if not f or not l:
            return []

        fi = f[0]
        li = l[0]

        local_parts = [
            f"{f}.{l}",
            f"{f}{l}",
            f"{f}_{l}",
            f"{f}{li}",
            f"{fi}{l}",
            f"{l}{f}",
            f"{l}.{f}",
            f"{l}{fi}",
        ]
        if len(l) >= 3:
            local_parts.append(f"{f}{l[0:3]}")

        emails = []
        for domain in VERIFIABLE_PERSONAL_DOMAINS:
            for local in local_parts:
                emails.append(f"{local}@{domain}")

        return emails

    async def verify_personal_emails(self, first_name, last_name):
        patterns = self.generate_personal_patterns(first_name, last_name)
        if not patterns:
            return []

        logger.info(f"Checking {len(patterns)} personal patterns for {first_name} {last_name}")

        verified = []
        by_domain = {}
        for email in patterns:
            domain = email.split('@')[1]
            if domain not in by_domain:
                by_domain[domain] = []
            by_domain[domain].append(email)

        for domain, emails in by_domain.items():
            mx_host = await self._get_mx_host(domain)
            if not mx_host:
                continue

            # Check if domain is catch-all
            try:
                fake_check = await self._smtp_verify(f"zxqjk99fake99test@{domain}", mx_host)
                if fake_check:
                    logger.debug(f"{domain} is catch-all, skipping")
                    continue
            except Exception:
                continue

            # Verify in batches of 4
            for i in range(0, len(emails), 4):
                batch = emails[i:i + 4]
                results = await asyncio.gather(
                    *[self._smtp_verify(email, mx_host) for email in batch],
                    return_exceptions=True
                )
                for j, res in enumerate(results):
                    if isinstance(res, bool) and res:
                        verified.append(batch[j])
                        logger.info(f"Personal email verified: {batch[j]}")

                if len(verified) >= 2:
                    return verified[:2]

        return verified[:2]

    # --- Exhaustive Corporate Pattern Generation ---

    def generate_exhaustive_patterns(self, first, last, domain):
        f = re.sub(r'[^a-z]', '', first.lower().strip())
        l = re.sub(r'[^a-z]', '', last.lower().strip())
        if not f or not l:
            return []

        fi = f[0]
        li = l[0]

        patterns = []
        seen = set()

        def add(email):
            if email is None:
                return
            e = email.lower()
            if e not in seen:
                seen.add(e)
                patterns.append(e)

        add(f"{f}.{l}@{domain}")
        add(f"{f}{l}@{domain}")
        add(f"{fi}{l}@{domain}")
        add(f"{f}@{domain}")
        add(f"{f}{li}@{domain}")
        add(f"{fi}.{l}@{domain}")
        add(f"{l}.{f}@{domain}")
        add(f"{l}{fi}@{domain}")
        add(f"{l}@{domain}")
        add(f"{f}_{l}@{domain}")
        add(f"{f}-{l}@{domain}")

        add(f"{fi}{li}@{domain}")
        add(f"{l}{f}@{domain}")
        add(f"{f}.{li}@{domain}")
        if len(l) >= 3:
            add(f"{fi}{l[0:3]}@{domain}")
        add(f"{l}.{fi}@{domain}")
        add(f"{l}_{f}@{domain}")
        add(f"{l}-{f}@{domain}")
        add(f"{fi}_{l}@{domain}")
        add(f"{fi}-{l}@{domain}")

        if len(f) >= 3:
            add(f"{f[:3]}{l}@{domain}")
            add(f"{f[:3]}.{l}@{domain}")
            add(f"{f[:3]}{li}@{domain}")
        if len(l) >= 3:
            add(f"{f}{l[:3]}@{domain}")
            add(f"{f}.{l[:3]}@{domain}")
            add(f"{fi}{l[:3]}@{domain}")

        add(f"{f}.{l}1@{domain}")
        add(f"{f}{l}1@{domain}")
        add(f"{fi}{l}1@{domain}")

        name_parts = first.lower().strip().split()
        if len(name_parts) > 1:
            mi = name_parts[1][0] if name_parts[1] else ''
            fn = re.sub(r'[^a-z]', '', name_parts[0])
            if mi and fn:
                add(f"{fn}{mi}{l}@{domain}")
                add(f"{fn}.{mi}.{l}@{domain}")
                add(f"{fn}{mi}.{l}@{domain}")

        logger.info(f"Generated {len(patterns)} patterns for {first} {last} @ {domain}")
        return patterns

    # --- SMTP Verify ALL Patterns ---

    async def verify_all_patterns(self, patterns, domain):
        mx_host = await self._get_mx_host(domain)
        if not mx_host:
            return []

        verified = []
        batch_size = 8
        for i in range(0, len(patterns), batch_size):
            batch = patterns[i:i + batch_size]
            results = await asyncio.gather(
                *[self._smtp_verify(email, mx_host) for email in batch],
                return_exceptions=True
            )
            for j, result in enumerate(results):
                if isinstance(result, bool) and result:
                    verified.append(batch[j])

        logger.info(f"SMTP verified {len(verified)}/{len(patterns)} for {domain}: {verified}")
        return verified

    async def _smtp_verify(self, email, mx_host):
        try:
            smtp = aiosmtplib.SMTP(hostname=mx_host, port=25, timeout=SMTP_TIMEOUT, use_tls=False)
            await smtp.connect()
            await smtp.ehlo()
            try:
                await smtp.starttls()
                await smtp.ehlo()
            except Exception:
                pass
            await smtp.mail("verify@m365dispatcher.com")
            code, message = await smtp.rcpt(email)
            await smtp.quit()
            return code == 250
        except aiosmtplib.SMTPResponseException as e:
            if e.code in (550, 551, 552, 553):
                return False
            raise
        except Exception:
            return False

    # --- Catch-all Detection ---

    async def check_catchall(self, domain):
        mx_host = await self._get_mx_host(domain)
        if not mx_host:
            return False
        try:
            return await self._smtp_verify(f"zxqjk7829fake@{domain}", mx_host)
        except Exception:
            return False

    # --- Domain Discovery (improved) ---

    async def discover_domain(self, company_name):
        # Method 1: Clearbit
        try:
            url = f"https://autocomplete.clearbit.com/v1/companies/suggest?query={company_name}"
            resp = await self.http_client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                if data and len(data) > 0:
                    for entry in data[:3]:
                        domain = entry.get('domain', '')
                        name = entry.get('name', '').lower()
                        if domain and self._company_name_matches(company_name, name):
                            if await self._has_mx_record(domain):
                                logger.info(f"Clearbit: {company_name} -> {domain}")
                                return domain
                    domain = data[0].get('domain', '')
                    if domain and await self._has_mx_record(domain):
                        logger.info(f"Clearbit (first): {company_name} -> {domain}")
                        return domain
        except Exception as e:
            logger.debug(f"Clearbit failed: {e}")

        # Method 2: Company slug + TLDs
        slug = self._company_to_slug(company_name)
        if slug:
            for tld in ['.com', '.io', '.co', '.net', '.org', '.ai', '.dev', '.tech', '.app']:
                domain = slug + tld
                if await self._has_mx_record(domain):
                    logger.info(f"Slug: {company_name} -> {domain}")
                    return domain

        # Method 3: First word of company name
        words = re.sub(r'[^a-z0-9\s]', '', company_name.lower()).split()
        if len(words) > 1:
            for tld in ['.com', '.io', '.co', '.ai']:
                domain = words[0] + tld
                if len(words[0]) >= 3 and await self._has_mx_record(domain):
                    logger.info(f"FirstWord: {company_name} -> {domain}")
                    return domain

            for suffix in ['hq', 'app', 'inc']:
                domain = slug + suffix + '.com'
                if await self._has_mx_record(domain):
                    logger.info(f"Suffix: {company_name} -> {domain}")
                    return domain

        return None

    def _company_name_matches(self, search_name, result_name):
        s = re.sub(r'[^a-z0-9]', '', search_name.lower())
        r = re.sub(r'[^a-z0-9]', '', result_name.lower())
        return s in r or r in s or s[:5] == r[:5]

    # --- Website Scraping ---

    async def scrape_website_emails(self, domain, first_name, last_name):
        found = set()
        pages = [
            f"https://www.{domain}", f"https://www.{domain}/about",
            f"https://www.{domain}/about-us", f"https://www.{domain}/contact",
            f"https://www.{domain}/team", f"https://{domain}",
            f"https://{domain}/about", f"https://{domain}/contact",
        ]
        email_re = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', re.IGNORECASE)
        fn = first_name.lower().strip()
        ln = last_name.lower().strip()

        for url in pages:
            try:
                resp = await self.http_client.get(url)
                if resp.status_code != 200:
                    continue
                soup = BeautifulSoup(resp.text, 'html.parser')
                for tag in soup(['script', 'style']):
                    tag.decompose()
                emails = email_re.findall(soup.get_text())
                for a in soup.find_all('a', href=True):
                    if a['href'].startswith('mailto:'):
                        emails.append(a['href'].replace('mailto:', '').split('?')[0].strip())
                for email in emails:
                    email = email.lower().strip()
                    local = email.split('@')[0]
                    if local in GENERIC_PREFIXES:
                        continue
                    if fn in email or ln in email:
                        found.add(email)
            except Exception:
                continue

        return sorted(found, key=lambda e: (
            0 if fn in e and ln in e else 1 if ln in e else 2
        ))[:2]

    # --- DNS Helpers ---

    async def _get_mx_host(self, domain):
        try:
            loop = asyncio.get_event_loop()
            answers = await loop.run_in_executor(
                None, lambda: dns.resolver.resolve(domain, 'MX', lifetime=DNS_TIMEOUT)
            )
            mx_records = sorted(answers, key=lambda r: r.preference)
            if mx_records:
                return str(mx_records[0].exchange).rstrip('.')
        except Exception:
            pass
        return None

    async def _has_mx_record(self, domain):
        return (await self._get_mx_host(domain)) is not None

    def _company_to_slug(self, name):
        slug = name.lower().strip()
        for suffix in [' inc', ' inc.', ' llc', ' ltd', ' ltd.',
                       ' corp', ' corp.', ' co', ' co.',
                       ' group', ' holdings', ' international',
                       ' technologies', ' technology', ' tech',
                       ' solutions', ' services', ' consulting',
                       ' partners', ' & co', ' and co',
                       ', inc', ', llc', ', ltd',
                       ' labs', ' studio', ' studios',
                       ' digital', ' software', ' platform',
                       ' global', ' media', ' data',
                       ' systems', ' network', ' networks']:
            slug = slug.replace(suffix, '')
        return re.sub(r'[^a-z0-9]', '', slug)

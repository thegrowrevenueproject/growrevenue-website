#!/usr/bin/env python3
"""
M365 Dispatcher — Bulk CSV Importer

Imports contact lists (Apollo, GrowMeOrganic, or generic CSV) into
the persistent SQLite database used by the enricher.

Usage:
    python3 import_contacts.py /path/to/file1.csv /path/to/file2.csv ...
    python3 import_contacts.py /path/to/folder/  (imports all CSVs in folder)

Supports:
    - Apollo exports (First Name, Last Name, Email, Company, etc.)
    - GrowMeOrganic exports (first_name, last_name, email, company_name, etc.)
    - Generic CSVs (auto-detects column names)

All imported contacts get:
    - confidence: 70 (imported, not SMTP-verified by us)
    - source: "apollo_import" / "gmo_import" / "csv_import"
    - Permanent storage in SQLite — survives restarts forever
"""

import csv
import json
import os
import sqlite3
import sys
import time
import glob
from pathlib import Path

DB_PATH = "/opt/m365-api/email_cache.db"

# ─── Column name mappings for different CSV formats ───────────────────

COLUMN_MAPS = {
    "apollo": {
        "first_name": ["First Name", "first_name", "firstName"],
        "last_name": ["Last Name", "last_name", "lastName"],
        "email": ["Email", "email", "Email Address", "Work Email", "Personal Email"],
        "email_second": ["Personal Email", "Home Email", "personal_email", "Email 2"],
        "company": ["Company", "company", "Company Name", "Organization Name", "company_name"],
        "domain": ["Company Domain", "Website", "company_domain", "domain", "Email Domain"],
        "phone": ["Phone", "phone", "Mobile Phone", "Work Phone", "Phone Number",
                   "Corporate Phone", "Work Direct Phone", "Home Phone"],
        "title": ["Title", "title", "Job Title", "job_title"],
        "linkedin": ["LinkedIn URL", "linkedin_url", "Person Linkedin Url", "LinkedIn"],
        "location": ["City", "city", "State", "Location", "location"],
        "industry": ["Industry", "industry"],
        "employees": ["# Employees", "employees", "Company Size", "Employee Count"],
    },
    "gmo": {
        "first_name": ["first_name", "First Name"],
        "last_name": ["last_name", "Last Name"],
        "email": ["email", "Email", "email_1", "Email 1"],
        "email_second": ["email_2", "Email 2", "personal_email"],
        "company": ["company_name", "Company", "company", "organization"],
        "domain": ["company_domain", "domain", "website"],
        "phone": ["phone", "Phone", "phone_number", "mobile"],
        "title": ["title", "Title", "job_title", "designation"],
        "linkedin": ["linkedin_url", "LinkedIn", "profile_url", "linkedin"],
        "location": ["location", "Location", "city", "City"],
    },
}


def detect_format(headers):
    """Detect CSV format based on column headers."""
    headers_lower = [h.lower().strip() for h in headers]

    # Apollo exports typically have these
    apollo_signals = ["first name", "last name", "company", "# employees",
                      "company domain", "person linkedin url"]
    gmo_signals = ["first_name", "last_name", "company_name", "linkedin_url",
                   "email_1", "designation"]

    apollo_score = sum(1 for s in apollo_signals if s in headers_lower)
    gmo_score = sum(1 for s in gmo_signals if s in headers_lower)

    if apollo_score >= 2:
        return "apollo"
    elif gmo_score >= 2:
        return "gmo"
    else:
        return "generic"


def find_column(headers, field_names):
    """Find the first matching column name from a list of possible names."""
    for name in field_names:
        if name in headers:
            return name
    # Case-insensitive fallback
    headers_lower = {h.lower(): h for h in headers}
    for name in field_names:
        if name.lower() in headers_lower:
            return headers_lower[name.lower()]
    return None


def map_row(row, headers, fmt):
    """Map a CSV row to our standard format."""
    col_map = COLUMN_MAPS.get(fmt, COLUMN_MAPS["apollo"])
    result = {}

    for field, possible_names in col_map.items():
        col = find_column(headers, possible_names)
        if col and col in row:
            val = row[col].strip() if row[col] else ""
            result[field] = val
        else:
            result[field] = ""

    # If generic format, try to auto-detect
    if fmt == "generic":
        for h in headers:
            hl = h.lower().strip()
            if not result.get("first_name") and hl in ("first name", "first_name", "firstname", "fname", "first"):
                result["first_name"] = row.get(h, "").strip()
            if not result.get("last_name") and hl in ("last name", "last_name", "lastname", "lname", "last", "surname"):
                result["last_name"] = row.get(h, "").strip()
            if not result.get("email") and hl in ("email", "email address", "e-mail", "email1", "work email"):
                result["email"] = row.get(h, "").strip()
            if not result.get("company") and hl in ("company", "company name", "organization", "org", "employer"):
                result["company"] = row.get(h, "").strip()
            if not result.get("domain") and hl in ("domain", "company domain", "website", "web"):
                result["domain"] = row.get(h, "").strip()
            if not result.get("phone") and hl in ("phone", "phone number", "mobile", "tel", "telephone"):
                result["phone"] = row.get(h, "").strip()

    return result


def extract_domain_from_email(email):
    """Get domain from email address."""
    if "@" in email:
        domain = email.split("@")[1].lower()
        # Skip personal email domains
        personal = {"gmail.com", "yahoo.com", "hotmail.com", "outlook.com",
                    "aol.com", "icloud.com", "live.com", "msn.com", "me.com",
                    "comcast.net", "verizon.net", "att.net", "sbcglobal.net",
                    "ymail.com", "mail.com", "protonmail.com"}
        if domain not in personal:
            return domain
    return ""


def init_db(db_path):
    """Initialize database with the same schema as enricher.py."""
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS email_cache (
            lookup_key TEXT PRIMARY KEY,
            first_name TEXT,
            last_name TEXT,
            company_name TEXT,
            email TEXT,
            email_second TEXT,
            phone TEXT,
            company_domain TEXT,
            confidence INTEGER DEFAULT 0,
            method TEXT,
            source TEXT DEFAULT 'smtp',
            raw_json TEXT,
            created_at REAL,
            updated_at REAL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_email ON email_cache(email)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_domain ON email_cache(company_domain)")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS domain_cache (
            company_name_lower TEXT PRIMARY KEY,
            domain TEXT,
            created_at REAL
        )
    """)
    conn.commit()
    return conn


def import_csv(filepath, conn, stats):
    """Import a single CSV file into the database."""
    filename = os.path.basename(filepath)
    print(f"\n{'='*60}")
    print(f"  Importing: {filename}")
    print(f"{'='*60}")

    # Detect encoding
    encodings = ["utf-8-sig", "utf-8", "latin-1", "cp1252"]
    rows = []
    headers = []
    fmt = "generic"

    for enc in encodings:
        try:
            with open(filepath, "r", encoding=enc) as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames or []
                rows = list(reader)
            break
        except (UnicodeDecodeError, csv.Error):
            continue

    if not rows:
        print(f"  ERROR: Could not read {filename}")
        return

    fmt = detect_format(headers)
    source = f"{fmt}_import"

    print(f"  Format: {fmt} | Rows: {len(rows)} | Columns: {len(headers)}")
    print(f"  Headers: {', '.join(headers[:8])}{'...' if len(headers) > 8 else ''}")

    imported = 0
    skipped_no_name = 0
    skipped_no_email = 0
    skipped_duplicate = 0
    domains_added = 0
    now = time.time()

    # Batch insert for speed
    batch = []
    domain_batch = []

    for row in rows:
        mapped = map_row(row, headers, fmt)

        first = mapped.get("first_name", "").strip()
        last = mapped.get("last_name", "").strip()
        email = mapped.get("email", "").strip().lower()
        company = mapped.get("company", "").strip()

        # Handle full name in one field
        if not first and not last:
            name = mapped.get("name", row.get("Name", row.get("name", ""))).strip()
            if name:
                parts = name.split(" ", 1)
                first = parts[0]
                last = parts[1] if len(parts) > 1 else ""

        if not first or not last:
            skipped_no_name += 1
            continue

        if not email or "@" not in email:
            skipped_no_email += 1
            continue

        # Build lookup key (same as enricher.py)
        key = f"{first.lower()}:{last.lower()}:{company.lower()}"

        # Get domain
        domain = mapped.get("domain", "").strip().lower()
        if not domain:
            domain = extract_domain_from_email(email)

        # Clean domain (remove http/www)
        domain = domain.replace("https://", "").replace("http://", "").replace("www.", "").strip("/")

        email_second = mapped.get("email_second", "").strip().lower() or None
        phone = mapped.get("phone", "").strip() or None

        result = {
            "email": email,
            "email_second": email_second,
            "phone": phone,
            "company_domain": domain or None,
            "company_phone": None,
            "confidence": 70,
            "method": f"{fmt}_import"
        }

        batch.append((
            key, first.lower(), last.lower(), company.lower(),
            email, email_second, phone, domain or None,
            70, f"{fmt}_import", source, json.dumps(result), now, now
        ))

        # Cache domain mapping
        if domain and company:
            domain_batch.append((company.lower(), domain, now))

        if len(batch) >= 5000:
            try:
                conn.executemany("""
                    INSERT OR IGNORE INTO email_cache
                    (lookup_key, first_name, last_name, company_name,
                     email, email_second, phone, company_domain,
                     confidence, method, source, raw_json, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, batch)
                imported += conn.total_changes
            except Exception as e:
                print(f"  Batch error: {e}")
            batch = []

            if domain_batch:
                try:
                    conn.executemany("""
                        INSERT OR IGNORE INTO domain_cache
                        (company_name_lower, domain, created_at)
                        VALUES (?, ?, ?)
                    """, domain_batch)
                    domains_added += len(domain_batch)
                except Exception:
                    pass
                domain_batch = []

    # Final batch
    if batch:
        before = conn.execute("SELECT COUNT(*) FROM email_cache").fetchone()[0]
        try:
            conn.executemany("""
                INSERT OR IGNORE INTO email_cache
                (lookup_key, first_name, last_name, company_name,
                 email, email_second, phone, company_domain,
                 confidence, method, source, raw_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, batch)
            conn.commit()
        except Exception as e:
            print(f"  Final batch error: {e}")
        after = conn.execute("SELECT COUNT(*) FROM email_cache").fetchone()[0]
        imported = after - before + imported

    if domain_batch:
        try:
            conn.executemany("""
                INSERT OR IGNORE INTO domain_cache
                (company_name_lower, domain, created_at)
                VALUES (?, ?, ?)
            """, domain_batch)
            conn.commit()
        except Exception:
            pass

    conn.commit()

    total_rows = len(rows)
    print(f"\n  Results:")
    print(f"    Total rows:        {total_rows}")
    print(f"    Imported (new):    {imported}")
    print(f"    Skipped (no name): {skipped_no_name}")
    print(f"    Skipped (no email):{skipped_no_email}")
    print(f"    Domains cached:    {domains_added}")

    stats["total_rows"] += total_rows
    stats["imported"] += imported
    stats["skipped_name"] += skipped_no_name
    stats["skipped_email"] += skipped_no_email
    stats["files"] += 1


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 import_contacts.py <file.csv> [file2.csv ...] [/folder/]")
        print("\nImports Apollo, GrowMeOrganic, or generic CSV contact lists")
        print("into the M365 Dispatcher enrichment database.")
        print(f"\nDatabase: {DB_PATH}")
        sys.exit(1)

    # Collect all CSV files
    csv_files = []
    for arg in sys.argv[1:]:
        if os.path.isdir(arg):
            csv_files.extend(sorted(glob.glob(os.path.join(arg, "*.csv"))))
        elif os.path.isfile(arg):
            csv_files.append(arg)
        else:
            print(f"WARNING: {arg} not found, skipping")

    if not csv_files:
        print("No CSV files found!")
        sys.exit(1)

    print(f"\n{'#'*60}")
    print(f"  M365 DISPATCHER — BULK CONTACT IMPORTER")
    print(f"  Database: {DB_PATH}")
    print(f"  Files to import: {len(csv_files)}")
    print(f"{'#'*60}")

    conn = init_db(DB_PATH)

    # Show current DB size
    before = conn.execute("SELECT COUNT(*) FROM email_cache").fetchone()[0]
    print(f"\n  Current DB size: {before:,} contacts")

    stats = {"total_rows": 0, "imported": 0, "skipped_name": 0,
             "skipped_email": 0, "files": 0}

    for filepath in csv_files:
        try:
            import_csv(filepath, conn, stats)
        except Exception as e:
            print(f"\n  ERROR importing {filepath}: {e}")
            continue

    # Final stats
    after = conn.execute("SELECT COUNT(*) FROM email_cache").fetchone()[0]
    domains = conn.execute("SELECT COUNT(*) FROM domain_cache").fetchone()[0]

    by_source = {}
    for row in conn.execute("SELECT source, COUNT(*) FROM email_cache GROUP BY source"):
        by_source[row[0]] = row[1]

    conn.close()

    print(f"\n{'#'*60}")
    print(f"  IMPORT COMPLETE")
    print(f"{'#'*60}")
    print(f"  Files processed:  {stats['files']}")
    print(f"  Total CSV rows:   {stats['total_rows']:,}")
    print(f"  New contacts:     {after - before:,}")
    print(f"  Skipped (no name):{stats['skipped_name']:,}")
    print(f"  Skipped (no email):{stats['skipped_email']:,}")
    print(f"\n  Database now: {after:,} contacts | {domains:,} domains")
    print(f"\n  By source:")
    for src, count in sorted(by_source.items(), key=lambda x: -x[1]):
        print(f"    {src}: {count:,}")
    print()


if __name__ == "__main__":
    main()

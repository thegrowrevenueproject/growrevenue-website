# M365 Dispatcher — LinkedIn Scraper + Email Enrichment

## Project Structure

```
m365-scraper/
├── extension/                  # Chrome Extension
│   ├── manifest.json           # Manifest V3 config
│   ├── inject.js               # XHR interceptor (captures LinkedIn API responses)
│   ├── content.js              # UI bar, enrichment, CSV export, bulk scrape
│   ├── content.css             # Bottom bar and panel styling
│   ├── popup.html              # Extension popup with stats
│   └── icon.png                # Extension icon
│
├── backend/                    # Python Enrichment API
│   ├── main.py                 # FastAPI server with routes
│   ├── enricher.py             # Email enrichment engine
│   ├── cache.py                # SQLite cache layer
│   ├── requirements.txt        # Python dependencies
│   ├── nginx-m365-api.conf     # Nginx reverse proxy config
│   ├── m365-api.service        # Systemd service file
│   └── DEPLOY.sh               # Step-by-step VPS deployment guide
│
└── README.md                   # This file
```

## How It Works

```
LinkedIn (Chrome Extension)
├── User browses LinkedIn search / Sales Navigator
├── inject.js intercepts XHR API responses
├── Extracts: name, title, company, location, LinkedIn ID, profile URL
├── Captures email if visible (1st degree / open profile / Sales Nav contactInfo)
├── For missing emails → sends to Enrichment Backend
│
Enrichment Backend (Python FastAPI on Contabo VPS)
├── Receives: first_name, last_name, company_name
├── Step 1: Domain discovery (MX lookup + company name → domain guess)
├── Step 2: Pattern generation (15+ email patterns)
├── Step 3: SMTP verification (MX lookup + SMTP handshake)
├── Step 4: Website scraping (find emails on /about, /contact, /team)
├── Returns: verified email + confidence score
│
CSV Export → M365 Dispatcher (Outlook VSTO Add-in)
├── Extension exports CSV with: Email, First Name, Last Name, Company, etc.
├── CSV imports directly into M365 Dispatcher campaign
└── Ready to send
```

## Expected Results (per 100 profiles)

| Source | Count | Method |
|--------|-------|--------|
| LinkedIn visible email | ~10 | 1st degree / open profile |
| SMTP verified pattern | ~50-55 | Pattern guess + SMTP handshake |
| Website scrape | ~5-10 | Company website crawl |
| **Total emails found** | **~60-70** | **Free, no APIs needed** |

## Quick Start

### 1. Load Chrome Extension
1. Open `chrome://extensions/` in Chrome
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select the `extension/` folder
5. Navigate to LinkedIn — the bottom bar should appear

### 2. Deploy Backend to VPS
Follow the commands in `backend/DEPLOY.sh` on your Contabo VPS.

### 3. Configure Extension
1. Click the ⋯ button in the bottom bar
2. Set the API URL to `https://api.m365dispatcher.com`
3. Click "Test" to verify connection

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check + cache stats |
| POST | `/enrich` | Enrich single contact |
| POST | `/enrich/bulk` | Enrich up to 50 contacts |
| GET | `/cache/stats` | Cache hit/miss stats |
| DELETE | `/cache/clear` | Clear enrichment cache |

### Enrich Request
```json
POST /enrich
{
  "first_name": "John",
  "last_name": "Smith",
  "company_name": "Acme Corp",
  "company_domain": "",
  "linkedin_url": ""
}
```

### Enrich Response
```json
{
  "email": "john.smith@acmecorp.com",
  "email_second": null,
  "phone": null,
  "company_domain": "acmecorp.com",
  "confidence": 95,
  "method": "smtp_verified",
  "cached": false
}
```

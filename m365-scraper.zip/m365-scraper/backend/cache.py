"""
M365 Dispatcher — Enrichment Cache
SQLite-based cache to avoid re-enriching the same person.
"""

import json
import logging
import sqlite3
import threading
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

CACHE_TTL_DAYS = 30  # Cache results for 30 days


class EnrichmentCache:
    """Thread-safe SQLite cache for enrichment results."""

    def __init__(self, db_path: str = "enrichment_cache.db"):
        self.db_path = db_path
        self.hits = 0
        self.misses = 0
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    data TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)
            """)
            conn.commit()
            conn.close()

    def get(self, key: str) -> Optional[dict]:
        """Get cached result. Returns None if not found or expired."""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.execute(
                "SELECT data, expires_at FROM cache WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            conn.close()

            if row:
                data, expires_at = row
                if datetime.fromisoformat(expires_at) > datetime.utcnow():
                    self.hits += 1
                    return json.loads(data)
                else:
                    # Expired — clean up
                    self._delete(key)

            self.misses += 1
            return None

    def set(self, key: str, data: dict):
        """Cache enrichment result."""
        now = datetime.utcnow()
        expires = now + timedelta(days=CACHE_TTL_DAYS)

        with self._lock:
            conn = sqlite3.connect(self.db_path)
            conn.execute(
                """INSERT OR REPLACE INTO cache (key, data, created_at, expires_at)
                   VALUES (?, ?, ?, ?)""",
                (key, json.dumps(data), now.isoformat(), expires.isoformat())
            )
            conn.commit()
            conn.close()

    def _delete(self, key: str):
        conn = sqlite3.connect(self.db_path)
        conn.execute("DELETE FROM cache WHERE key = ?", (key,))
        conn.commit()
        conn.close()

    def size(self) -> int:
        """Number of cached entries."""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.execute("SELECT COUNT(*) FROM cache")
            count = cursor.fetchone()[0]
            conn.close()
            return count

    def clear(self):
        """Clear all cache."""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            conn.execute("DELETE FROM cache")
            conn.commit()
            conn.close()
            self.hits = 0
            self.misses = 0
            logger.info("Cache cleared")

    def cleanup_expired(self):
        """Remove expired entries."""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            now = datetime.utcnow().isoformat()
            cursor = conn.execute(
                "DELETE FROM cache WHERE expires_at < ?",
                (now,)
            )
            deleted = cursor.rowcount
            conn.commit()
            conn.close()
            if deleted > 0:
                logger.info(f"Cleaned up {deleted} expired cache entries")

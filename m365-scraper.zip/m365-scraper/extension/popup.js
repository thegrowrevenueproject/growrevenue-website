// ─── Constants ───────────────────────────────────────────────────────
var OWNER_KEY = 'CP-OWNER-GROWREVENUE-2026-UNLIMITED';
var OWNER_PWD = 'GrOwReVeNuE2026!';

// ─── Init ────────────────────────────────────────────────────────────
chrome.storage.local.get(['cp_license_valid', 'cp_license_key', 'cp_is_owner'], function (data) {
  var isOwnerKey = data.cp_license_key === OWNER_KEY && data.cp_is_owner === true;
  var isValid = data.cp_license_valid === true && !!data.cp_license_key;
  if (isOwnerKey || isValid) {
    showLicensedView();
  } else {
    showGateView();
  }
});

function showGateView() {
  document.getElementById('gate-view').style.display = 'block';
  document.getElementById('licensed-view').style.display = 'none';
}

function showLicensedView() {
  document.getElementById('gate-view').style.display = 'none';
  document.getElementById('licensed-view').style.display = 'block';
  loadStats();
  loadLicenseInfo();
  checkBackend();
}

// ─── Trial Button ────────────────────────────────────────────────────
document.getElementById('btn-trial').addEventListener('click', function () {
  chrome.tabs.create({ url: 'https://coldpumper.com/trial' });
});

// ─── Activate Button ─────────────────────────────────────────────────
document.getElementById('btn-activate').addEventListener('click', function () {
  var email = document.getElementById('inp-email').value.trim();
  var key = document.getElementById('inp-key').value.trim();
  var pass = document.getElementById('inp-pass').value.trim();
  var errEl = document.getElementById('gate-err');
  var okEl = document.getElementById('gate-ok');
  var btn = document.getElementById('btn-activate');

  errEl.style.display = 'none';
  okEl.style.display = 'none';

  if (!email || !key || !pass) {
    errEl.textContent = 'Please fill in all fields.';
    errEl.style.display = 'block';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Verifying...';

  // Owner key — handle directly, zero dependencies
  if (key === OWNER_KEY && pass === OWNER_PWD) {
    chrome.storage.local.set({
      cp_license_key: OWNER_KEY,
      cp_password: OWNER_PWD,
      cp_email: email,
      cp_plan: 'unlimited',
      cp_status: 'active',
      cp_customer_name: 'Owner',
      cp_activations_used: 1,
      cp_activations_max: 999,
      cp_features: {},
      cp_license_valid: true,
      cp_last_verified: Date.now(),
      cp_is_owner: true
    }, function () {
      btn.disabled = false;
      btn.textContent = '\uD83D\uDD11 Activate License';
      okEl.textContent = '\u2705 License activated! Plan: unlimited';
      okEl.style.display = 'block';
      try {
        chrome.tabs.query({ url: '*://*.linkedin.com/*' }, function (tabs) {
          (tabs || []).forEach(function (tab) {
            chrome.tabs.sendMessage(tab.id, { type: 'LICENSE_ACTIVATED' }).catch(function () {});
          });
        });
      } catch (e) {}
      setTimeout(function () { showLicensedView(); }, 1000);
    });
    return;
  }

  // Regular key — try background first, fallback to direct fetch
  function tryServerDirect() {
    fetch('https://api.coldpumper.com/api/verify-license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        license_key: key, password: pass, email: email,
        machine_id: 'EX-popup', product_type: 'chrome_extension'
      })
    }).then(function (r) { return r.json(); }).then(function (data) {
      btn.disabled = false;
      btn.textContent = '\uD83D\uDD11 Activate License';
      if (data.status === 'active' || data.status === 'trial') {
        chrome.storage.local.set({
          cp_license_key: key, cp_password: pass, cp_email: email,
          cp_plan: data.plan_tier, cp_status: data.status,
          cp_customer_name: data.customer_name || '',
          cp_activations_used: data.activations_used || 0,
          cp_activations_max: data.activations_max || 2,
          cp_features: data.features || {},
          cp_license_valid: true, cp_last_verified: Date.now(), cp_is_owner: false
        });
        okEl.textContent = '\u2705 License activated! Plan: ' + data.plan_tier;
        okEl.style.display = 'block';
        setTimeout(function () { showLicensedView(); }, 1000);
      } else {
        errEl.textContent = data.error || 'License not active.';
        errEl.style.display = 'block';
      }
    }).catch(function () {
      btn.disabled = false;
      btn.textContent = '\uD83D\uDD11 Activate License';
      errEl.textContent = 'Could not reach license server. Please check your key and try again.';
      errEl.style.display = 'block';
    });
  }

  try {
    chrome.runtime.sendMessage({
      type: 'VERIFY_LICENSE', key: key, password: pass, email: email
    }, function (result) {
      if (chrome.runtime.lastError || !result) {
        tryServerDirect();
        return;
      }
      btn.disabled = false;
      btn.textContent = '\uD83D\uDD11 Activate License';
      if (result.success) {
        okEl.textContent = '\u2705 License activated! Plan: ' + (result.plan || 'active');
        okEl.style.display = 'block';
        setTimeout(function () { showLicensedView(); }, 1000);
      } else {
        errEl.textContent = result.error || 'Activation failed.';
        errEl.style.display = 'block';
      }
    });
  } catch (e) {
    tryServerDirect();
  }
});

// Enter key triggers activate
document.getElementById('inp-pass').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') document.getElementById('btn-activate').click();
});

// ─── Deactivate ──────────────────────────────────────────────────────
document.getElementById('btn-deactivate').addEventListener('click', function () {
  if (!confirm('Deactivate license on this browser? You can reactivate later.')) return;
  chrome.storage.local.remove([
    'cp_license_key', 'cp_password', 'cp_email', 'cp_plan',
    'cp_status', 'cp_customer_name', 'cp_activations_used',
    'cp_activations_max', 'cp_features', 'cp_license_valid',
    'cp_last_verified', 'cp_is_owner', 'cp_contacts_scraped_today',
    'cp_scrape_date', 'cp_linkedin_account'
  ], function () {
    try {
      chrome.tabs.query({ url: '*://*.linkedin.com/*' }, function (tabs) {
        (tabs || []).forEach(function (tab) {
          chrome.tabs.sendMessage(tab.id, { type: 'LICENSE_DEACTIVATED' }).catch(function () {});
        });
      });
    } catch (e) {}
    showGateView();
  });
});

// ─── Load Stats ──────────────────────────────────────────────────────
function loadStats() {
  chrome.storage.local.get(['m365_lists'], function (d) {
    var L = d.m365_lists || {}, tp = 0, te = 0;
    Object.keys(L).forEach(function (n) {
      var p = L[n].profiles || {};
      tp += Object.keys(p).length;
      te += Object.values(p).filter(function (x) { return x.email_first; }).length;
    });
    document.getElementById('t').textContent = tp;
    document.getElementById('e').textContent = te;
  });
}

// ─── Load License Info ───────────────────────────────────────────────
function loadLicenseInfo() {
  chrome.storage.local.get([
    'cp_status', 'cp_plan', 'cp_email', 'cp_activations_used', 'cp_activations_max'
  ], function (info) {
    var statusEl = document.getElementById('lic-status');
    var status = (info.cp_status || 'unknown').toUpperCase();
    statusEl.textContent = status;
    statusEl.className = 'lic-val ' + (info.cp_status === 'active' ? 'active' : info.cp_status === 'trial' ? 'trial' : 'expired');
    document.getElementById('lic-plan').textContent = (info.cp_plan || '\u2014').toUpperCase();
    document.getElementById('lic-email').textContent = info.cp_email || '\u2014';
    document.getElementById('lic-slots').textContent = (info.cp_activations_used || 0) + '/' + (info.cp_activations_max || 2);
  });
}

// ─── Check Backend ───────────────────────────────────────────────────
function checkBackend() {
  chrome.storage.local.get(['m365_api_base'], function (d) {
    var api = d.m365_api_base || 'https://api.m365dispatcher.com';
    fetch(api + '/health', { signal: AbortSignal.timeout(5000) })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        document.getElementById('d').className = 'dot ok';
        document.getElementById('bt').textContent = 'Backend v' + (data.version || '?') + ' connected';
      })
      .catch(function () {
        document.getElementById('d').className = 'dot err';
        document.getElementById('bt').textContent = 'Backend offline';
      });
  });
}

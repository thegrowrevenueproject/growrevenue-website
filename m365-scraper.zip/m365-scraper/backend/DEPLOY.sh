# M365 Dispatcher — VPS Deployment Guide
# Run these commands on your Contabo VPS (164.68.121.163)
# SSH in first: ssh root@164.68.121.163

# ═══════════════════════════════════════════════════════════════════
# STEP 1: Install Python 3.11+ and system dependencies
# ═══════════════════════════════════════════════════════════════════

sudo apt update && sudo apt upgrade -y

# Install Python
sudo apt install -y python3 python3-pip python3-venv python3-dev

# Install Nginx (reverse proxy)
sudo apt install -y nginx

# Install Certbot (SSL certificates)
sudo apt install -y certbot python3-certbot-nginx

# Verify Python version (should be 3.10+)
python3 --version

# ═══════════════════════════════════════════════════════════════════
# STEP 2: Create app directory and upload files
# ═══════════════════════════════════════════════════════════════════

sudo mkdir -p /opt/m365-api
cd /opt/m365-api

# Upload these backend files to /opt/m365-api/:
#   main.py
#   enricher.py
#   cache.py
#   requirements.txt
#
# You can use SCP from your local machine:
#   scp main.py enricher.py cache.py requirements.txt root@164.68.121.163:/opt/m365-api/

# ═══════════════════════════════════════════════════════════════════
# STEP 3: Create Python virtual environment and install deps
# ═══════════════════════════════════════════════════════════════════

cd /opt/m365-api
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Quick test — start the server manually
uvicorn main:app --host 0.0.0.0 --port 8000
# Visit http://164.68.121.163:8000/health — should return {"status":"ok"}
# Press Ctrl+C to stop

# ═══════════════════════════════════════════════════════════════════
# STEP 4: Set up Nginx
# ═══════════════════════════════════════════════════════════════════

# First, create a simple HTTP config (no SSL yet)
sudo tee /etc/nginx/sites-available/m365-api > /dev/null << 'EOF'
server {
    listen 80;
    server_name api.m365dispatcher.com;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # CORS for Chrome extension
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS, DELETE" always;
        add_header Access-Control-Allow-Headers "Content-Type, Authorization" always;

        if ($request_method = OPTIONS) {
            return 204;
        }
    }
}
EOF

# Enable the site
sudo ln -sf /etc/nginx/sites-available/m365-api /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and restart Nginx
sudo nginx -t
sudo systemctl restart nginx

# ═══════════════════════════════════════════════════════════════════
# STEP 5: Get SSL certificate (AFTER DNS propagation)
# ═══════════════════════════════════════════════════════════════════

# Make sure api.m365dispatcher.com points to 164.68.121.163 first!
# Test: nslookup api.m365dispatcher.com

# Start the FastAPI server temporarily for certbot verification
cd /opt/m365-api
source venv/bin/activate
uvicorn main:app --host 127.0.0.1 --port 8000 &

# Get SSL cert
sudo certbot --nginx -d api.m365dispatcher.com --non-interactive --agree-tos --email your-email@m365dispatcher.com

# Kill the temp server
kill %1

# Certbot automatically updates the Nginx config with SSL.
# Restart Nginx to apply:
sudo systemctl restart nginx

# ═══════════════════════════════════════════════════════════════════
# STEP 6: Set up systemd service (auto-start on boot)
# ═══════════════════════════════════════════════════════════════════

sudo tee /etc/systemd/system/m365-api.service > /dev/null << 'EOF'
[Unit]
Description=M365 Dispatcher Enrichment API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/m365-api
ExecStart=/opt/m365-api/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 2
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable m365-api
sudo systemctl start m365-api

# Check it's running:
sudo systemctl status m365-api

# View logs:
sudo journalctl -u m365-api -f

# ═══════════════════════════════════════════════════════════════════
# STEP 7: Open firewall ports
# ═══════════════════════════════════════════════════════════════════

# Make sure ports 80, 443, and 25 (outbound) are open
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
# Port 25 outbound is needed for SMTP verification
# Most VPS providers allow this by default

# If ufw isn't active, enable it:
# sudo ufw enable

# ═══════════════════════════════════════════════════════════════════
# STEP 8: Verify everything works
# ═══════════════════════════════════════════════════════════════════

# Test health endpoint:
curl https://api.m365dispatcher.com/health

# Test enrichment:
curl -X POST https://api.m365dispatcher.com/enrich \
  -H "Content-Type: application/json" \
  -d '{"first_name":"John","last_name":"Smith","company_name":"Microsoft"}'

# You should see a JSON response with email, confidence, and method.

# ═══════════════════════════════════════════════════════════════════
# DONE! The enrichment API is now live at:
# https://api.m365dispatcher.com
#
# The Chrome extension will call:
# POST https://api.m365dispatcher.com/enrich
# GET  https://api.m365dispatcher.com/health
# ═══════════════════════════════════════════════════════════════════

# ─── MAINTENANCE COMMANDS ──────────────────────────────────────────

# Restart the API:
sudo systemctl restart m365-api

# View live logs:
sudo journalctl -u m365-api -f

# Update the code:
cd /opt/m365-api
# Upload new files, then:
sudo systemctl restart m365-api

# Renew SSL (auto-renews, but manual if needed):
sudo certbot renew

# Check cache stats:
curl https://api.m365dispatcher.com/cache/stats

# Clear cache:
curl -X DELETE https://api.m365dispatcher.com/cache/clear

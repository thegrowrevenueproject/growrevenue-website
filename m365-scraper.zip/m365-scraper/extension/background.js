/**
 * ColdPumper — Background Service Worker
 * 
 * Handles:
 *  - 24-hour license heartbeat with usage telemetry (Layer 3)
 *  - Daily scrape counter reset
 *  - LinkedIn account detection relay (Layer 4)
 *  - Owner key bypass (no heartbeat needed)
 *  - Badge updates
 */

importScripts('license.js');

// ─── Setup heartbeat alarm on install/startup ────────────────────────

chrome.runtime.onInstalled.addListener(function () {
  chrome.alarms.create('licenseHeartbeat', { periodInMinutes: 1440 }); // 24h
  chrome.alarms.create('dailyReset', { periodInMinutes: 1440 }); // reset daily counters
  runHeartbeat();
});

chrome.runtime.onStartup.addListener(function () {
  chrome.alarms.create('licenseHeartbeat', { periodInMinutes: 1440 });
  chrome.alarms.create('dailyReset', { periodInMinutes: 1440 });
  runHeartbeat();
});

// ─── Alarm listener ──────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === 'licenseHeartbeat') {
    runHeartbeat();
  }
  if (alarm.name === 'dailyReset') {
    resetDailyCounters();
  }
});

// ─── Heartbeat logic ─────────────────────────────────────────────────

async function runHeartbeat() {
  // Owner — no heartbeat needed, always valid
  if (await isOwner()) {
    chrome.action.setBadgeText({ text: '' });
    return;
  }

  var licensed = await checkLicenseStatus();

  if (licensed) {
    chrome.action.setBadgeText({ text: '' });
  } else {
    var data = await chrome.storage.local.get('cp_license_key');
    if (data.cp_license_key) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
    }
  }
}

// ─── Daily counter reset ─────────────────────────────────────────────

async function resetDailyCounters() {
  var data = await chrome.storage.local.get('cp_scrape_date');
  var today = new Date().toISOString().slice(0, 10);
  if (data.cp_scrape_date !== today) {
    await chrome.storage.local.set({ cp_contacts_scraped_today: 0, cp_scrape_date: today });
  }
}

// ─── Message handler for content script / popup ──────────────────────

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

  // ── License check ──
  if (msg.type === 'CHECK_LICENSE') {
    isLicensed().then(function (valid) {
      sendResponse({ licensed: valid });
    });
    return true;
  }

  // ── License activation ──
  if (msg.type === 'VERIFY_LICENSE') {
    verifyLicense(msg.key, msg.password, msg.email).then(function (result) {
      if (result.success) {
        chrome.action.setBadgeText({ text: '' });
        chrome.tabs.query({ url: '*://*.linkedin.com/*' }, function (tabs) {
          tabs.forEach(function (tab) {
            chrome.tabs.sendMessage(tab.id, { type: 'LICENSE_ACTIVATED' }).catch(function () {});
          });
        });
      }
      sendResponse(result);
    });
    return true;
  }

  // ── License deactivation ──
  if (msg.type === 'DEACTIVATE_LICENSE') {
    deactivateLicense().then(function (result) {
      if (result.success) {
        chrome.action.setBadgeText({ text: '' });
        chrome.tabs.query({ url: '*://*.linkedin.com/*' }, function (tabs) {
          tabs.forEach(function (tab) {
            chrome.tabs.sendMessage(tab.id, { type: 'LICENSE_DEACTIVATED' }).catch(function () {});
          });
        });
      }
      sendResponse(result);
    });
    return true;
  }

  // ── Get license info ──
  if (msg.type === 'GET_LICENSE_INFO') {
    getLicenseInfo().then(function (info) {
      sendResponse(info);
    });
    return true;
  }

  // ── Layer 3: Increment daily scrape counter ──
  if (msg.type === 'INCREMENT_SCRAPE_COUNT') {
    incrementDailyScrapeCount(msg.count || 1).then(function () {
      sendResponse({ ok: true });
    });
    return true;
  }

  // ── Layer 3: Get daily scraped count ──
  if (msg.type === 'GET_DAILY_SCRAPED') {
    getDailyScrapedCount().then(function (count) {
      sendResponse({ count: count });
    });
    return true;
  }

  // ── Layer 4: Set LinkedIn account URL ──
  if (msg.type === 'SET_LINKEDIN_ACCOUNT') {
    setLinkedInAccount(msg.url).then(function () {
      sendResponse({ ok: true });
    });
    return true;
  }
});

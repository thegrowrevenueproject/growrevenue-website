/**
 * ColdPumper — LinkedIn Scraper Content Script v2.1
 * Full automated pipeline:
 * 1. License check (gates all functionality)
 * 2. Intercept profiles from page
 * 3. Enrich via DB (1.65M contacts) + SMTP + API providers
 * 4. Move to next page, repeat
 */
(function () {
  'use strict';

  var CONFIG = { API_BASE: 'https://api.m365dispatcher.com', VERSION: '2.2.1' };
  var API_KEYS = { apollo: '', hunter: '', snov: '', rocketreach: '' };
  var lists = {}, activeListName = '';
  var isScraping = false, isEnriching = false;
  var scrapeTimer = null, countdownTimer = null;
  var nextActionSec = 0, pageCount = 0, doneFirstPage = false;
  var panel = null;

  // inject.js runs automatically via manifest (world: MAIN)

  // ─── Receive profiles from inject.js ────────────────────────────────
  window.addEventListener('message', function (ev) {
    if (ev.data && ev.data.source === 'm365-dispatcher') {
      console.log('[M365 content] Received message:', ev.data.type, 'profiles:', ev.data.data ? Object.keys(ev.data.data).length : 0);
    }
    if (ev.source !== window || !ev.data || ev.data.source !== 'm365-dispatcher') return;
    if (ev.data.type === 'SAVE_PROFILES') processProfiles(ev.data.data);
  });

  function processProfiles(profiles) {
    console.log('[M365 content] processProfiles called, activeList:', activeListName, 'has list:', !!lists[activeListName]);
    if (!profiles || typeof profiles !== 'object') { console.log('[M365 content] No profiles object'); return; }
    if (!activeListName || !lists[activeListName]) { console.log('[M365 content] No active list!'); return; }
    var added = 0;
    Object.keys(profiles).forEach(function (id) {
      if (!id || id === 'undefined') return;
      var p = profiles[id];
      if (!p.user_first_name && !p.user_last_name) return;
      if (!lists[activeListName].profiles[id]) { lists[activeListName].profiles[id] = p; added++; }
      else {
        var ex = lists[activeListName].profiles[id];
        Object.keys(p).forEach(function (k) { if (p[k] && !ex[k]) ex[k] = p[k]; });
      }
    });
    if (added > 0) {
      saveLists(); updateStats();
      showStatus('Page ' + pageCount + ' | +' + added + ' new | Total: ' + getCount());
      // Layer 3: Report scrape count to background
      chrome.runtime.sendMessage({ type: 'INCREMENT_SCRAPE_COUNT', count: added }).catch(function () {});
    }
  }

  // ─── Storage ────────────────────────────────────────────────────────
  function saveLists() {
    try { chrome.storage.local.set({ m365_lists: lists, m365_active: activeListName }); } catch (e) {}
  }
  function loadData(cb) {
    chrome.storage.local.get(['m365_lists', 'm365_active', 'm365_api_base', 'm365_api_keys'], function (d) {
      if (d.m365_lists) lists = d.m365_lists;
      if (d.m365_active && lists[d.m365_active]) activeListName = d.m365_active;
      if (d.m365_api_base) CONFIG.API_BASE = d.m365_api_base;
      if (d.m365_api_keys) {
        if (d.m365_api_keys.apollo) API_KEYS.apollo = d.m365_api_keys.apollo;
        if (d.m365_api_keys.hunter) API_KEYS.hunter = d.m365_api_keys.hunter;
        if (d.m365_api_keys.snov) API_KEYS.snov = d.m365_api_keys.snov;
        if (d.m365_api_keys.rocketreach) API_KEYS.rocketreach = d.m365_api_keys.rocketreach;
      }
      if (Object.keys(lists).length === 0) {
        var name = 'My List ' + new Date().toISOString().slice(0, 10);
        lists[name] = { profiles: {}, createdAt: new Date().toISOString() };
        activeListName = name; saveLists();
      }
      if (cb) cb();
    });
  }

  // ─── List helpers ───────────────────────────────────────────────────
  function getProfiles() { return (activeListName && lists[activeListName]) ? lists[activeListName].profiles : {}; }
  function getCount() { return Object.keys(getProfiles()).length; }
  function getEmailCount() { return Object.values(getProfiles()).filter(function (p) { return p.email_first; }).length; }
  function createList(name) {
    name = name.trim(); if (!name || lists[name]) return false;
    lists[name] = { profiles: {}, createdAt: new Date().toISOString() };
    activeListName = name; saveLists(); return true;
  }
  function switchList(name) { if (lists[name]) { activeListName = name; saveLists(); updateStats(); refreshDropdown(); } }
  function deleteList(name) {
    if (!lists[name]) return; delete lists[name];
    var r = Object.keys(lists); activeListName = r.length > 0 ? r[0] : '';
    saveLists(); updateStats(); refreshDropdown();
  }

  // ─── Get CSRF Token (JSESSIONID) for LinkedIn API calls ─────────────
  function getCsrfToken() {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
      var c = cookies[i].trim();
      if (c.indexOf('JSESSIONID=') === 0) {
        return c.substring(11).replace(/"/g, '');
      }
    }
    return '';
  }

  // ─── Clearbit Domain Lookup (free, no API key) ───────────────────────
  async function lookupDomains() {
    var profiles = Object.values(getProfiles());
    var needDomain = profiles.filter(function (p) { return p.user_company_name && !p.company_domain && !p.domain_looked; });
    if (needDomain.length === 0) return;

    showStatus('Looking up ' + needDomain.length + ' company domains...');
    for (var i = 0; i < needDomain.length; i++) {
      var p = needDomain[i];
      try {
        var resp = await fetch('https://autocomplete.clearbit.com/v1/companies/suggest?query=' + encodeURIComponent(p.user_company_name));
        if (resp.ok) {
          var data = await resp.json();
          if (data && data[0] && data[0].domain) {
            p.company_domain = data[0].domain;
          }
        }
      } catch (e) {}
      p.domain_looked = true;
      if (i % 10 === 0) saveLists();
      await sleep(100); // Small delay to not hammer Clearbit
    }
    saveLists();
  }

  // ─── Fetch LinkedIn Contact Info via MAIN world RPC ──────────────────
  // Content script can't call LinkedIn APIs (wrong origin), so we ask
  // inject.js (page context) to do it and return results via postMessage

  var contactCallbacks = {};

  window.addEventListener('message', function (ev) {
    if (ev.data && ev.data.source === 'm365-dispatcher' && ev.data.type === 'M365_CONTACT_RESULT') {
      var rid = ev.data.requestId;
      if (rid && contactCallbacks[rid]) {
        contactCallbacks[rid](ev.data.result);
        delete contactCallbacks[rid];
      }
    }
  });

  function fetchContactInfoRPC(profileId, profileUrl) {
    return new Promise(function (resolve) {
      var rid = 'ci_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      console.log('[M365] RPC send: ' + rid + ' profileId=' + profileId + ' url=' + (profileUrl || '').substring(0, 40));
      var timer = setTimeout(function () {
        console.log('[M365] RPC TIMEOUT: ' + rid);
        delete contactCallbacks[rid]; resolve(null);
      }, 3000);
      contactCallbacks[rid] = function (result) {
        console.log('[M365] RPC response: ' + rid + ' result=' + JSON.stringify(result).substring(0, 100));
        clearTimeout(timer); resolve(result);
      };
      window.postMessage({
        source: 'm365-dispatcher', type: 'M365_FETCH_CONTACT',
        requestId: rid, profileId: profileId, profileUrl: profileUrl
      }, '*');
    });
  }

  async function fetchContactInfo(profile) {
    if (profile.contact_fetched) return;

    // Skip 3rd+ degree — LinkedIn never shares their contact info
    // Only fetch for 1st/2nd degree connections
    var degree = profile.degree || '';
    if (degree === '3' || degree === 'OUT_OF_NETWORK') {
      profile.contact_fetched = true;
      return;
    }

    // Extract Sales Nav profile ID
    var profileId = '';
    if (profile.user_url && profile.user_url.indexOf('/sales/people/') !== -1) {
      profileId = profile.user_url.split('/sales/people/')[1];
      if (profileId) profileId = profileId.split(',')[0].split('?')[0];
    }

    var profileUrl = profile.regular_url || profile.user_url || '';

    console.log('[M365 content] Fetching contactInfo for ' + (profile.user_first_name || '') + ' ' + (profile.user_last_name || '') + ' id=' + profileId);

    var result = await fetchContactInfoRPC(profileId, profileUrl);

    if (result) {
      console.log('[M365 content] ContactInfo result:', JSON.stringify(result));

      // Apply email from LinkedIn (personal email like gmail/yahoo)
      if (result.email) {
        if (!profile.email_first) {
          profile.email_first = result.email;
        } else if (!profile.email_second && result.email !== profile.email_first) {
          profile.email_second = result.email;
        }
      }
      if (result.email2) {
        if (!profile.email_first) {
          profile.email_first = result.email2;
        } else if (!profile.email_second && result.email2 !== profile.email_first) {
          profile.email_second = result.email2;
        }
      }
      // Phone
      if (result.phone && !profile.phone) {
        profile.phone = result.phone;
      }
      // Websites → company domain
      if (result.websites && result.websites.length > 0) {
        for (var w = 0; w < result.websites.length; w++) {
          if (!profile.company_domain && result.websites[w]) {
            try { profile.company_domain = new URL(result.websites[w]).hostname.replace('www.', ''); } catch (e) {}
          }
        }
      }
      // Store regular LinkedIn URL for future use
      if (result.flagshipUrl) profile.regular_url = result.flagshipUrl;
    }

    profile.contact_fetched = true;
  }

  // ─── Enrich via Backend (SMTP verification) ─────────────────────────
  async function enrichViaBackend(profile) {
    if (!profile.user_first_name || !profile.user_company_name) return;
    if (profile.email_first && profile.email_second) return;
    if (profile.enriched_at) return;

    try {
      var controller = new AbortController();
      var timeout = setTimeout(function() { controller.abort(); }, 30000);
      var resp = await fetch(CONFIG.API_BASE + '/enrich', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          first_name: profile.user_first_name, last_name: profile.user_last_name || '',
          company_name: profile.user_company_name,
          company_domain: profile.company_domain || '',
          linkedin_url: profile.user_url || '',
          api_keys: API_KEYS
        })
      });
      clearTimeout(timeout);
      if (resp.ok) {
        var data = await resp.json();
        console.log('[M365] Backend: ' + profile.user_first_name + ' → ' + (data.email||'none') + ' | ' + (data.email_second||'none') + ' | ' + data.method + ' (conf:' + data.confidence + ')');

        if (data.confidence > 0) {
          if (data.email) {
            if (!profile.email_first) profile.email_first = data.email;
            else if (!profile.email_second && data.email !== profile.email_first) {
              profile.email_second = data.email;
            }
          }
          if (data.email_second && !profile.email_second && data.email_second !== profile.email_first) {
            profile.email_second = data.email_second;
          }
        }

        if (data.company_domain && !profile.company_domain) profile.company_domain = data.company_domain;
        profile.email_confidence = data.confidence || 0;
        profile.email_method = data.method || '';
      }
    } catch (e) { console.log('[M365] Backend error:', e.message); }
    profile.enriched_at = new Date().toISOString();
  }

  // ─── Bulk Enrich via Backend (5 profiles at a time, parallel) ──────
  async function enrichBulk(profiles, pageNum) {
    var CHUNK = 25; // send all page profiles at once, backend handles 5 concurrent
    for (var i = 0; i < profiles.length; i += CHUNK) {
      if (!isScraping) return;
      var chunk = profiles.slice(i, i + CHUNK);

      var contacts = chunk.map(function(p) {
        return {
          first_name: p.user_first_name, last_name: p.user_last_name || '',
          company_name: p.user_company_name,
          company_domain: p.company_domain || '',
          linkedin_url: p.user_url || ''
        };
      });

      showStatus('Page ' + pageNum + ' — Enriching batch ' + Math.floor(i/CHUNK + 1) + ' (' + chunk.length + ' profiles)...');
      console.log('[M365] Bulk enrich: sending ' + chunk.length + ' profiles');

      try {
        var controller = new AbortController();
        var timeout = setTimeout(function() { controller.abort(); }, 120000); // 2 min timeout
        var resp = await fetch(CONFIG.API_BASE + '/enrich/bulk', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify(contacts)
        });
        clearTimeout(timeout);

        if (resp.ok) {
          var data = await resp.json();
          var results = data.results || [];
          var emailsFound = 0;

          for (var j = 0; j < results.length && j < chunk.length; j++) {
            var r = results[j];
            var p = chunk[j];

            if (r.confidence > 0) {
              if (r.email) {
                if (!p.email_first) p.email_first = r.email;
                else if (!p.email_second && r.email !== p.email_first) p.email_second = r.email;
              }
              if (r.email_second && !p.email_second && r.email_second !== p.email_first) {
                p.email_second = r.email_second;
              }
              if (p.email_first) emailsFound++;
            }

            if (r.company_domain && !p.company_domain) p.company_domain = r.company_domain;
            p.email_confidence = r.confidence || 0;
            p.email_method = r.method || '';
            p.enriched_at = new Date().toISOString();

            console.log('[M365] Bulk result: ' + p.user_first_name + ' → ' + (r.email||'none') + ' | ' + r.method + ' (conf:' + r.confidence + ')');
          }

          showStatus('Page ' + pageNum + ' — Batch done: ' + emailsFound + ' emails found | Total: ' + getEmailCount());
          updateStats();
        }
      } catch (e) {
        console.log('[M365] Bulk enrich error:', e.message);
        showStatus('Page ' + pageNum + ' — Bulk error: ' + (e.message || 'timeout') + ', falling back to single...');
        // Fallback: enrich one by one
        for (var k = 0; k < chunk.length; k++) {
          if (!isScraping) return;
          await enrichViaBackend(chunk[k]);
          showStatus('Page ' + pageNum + ' — Fallback: ' + (k+1) + '/' + chunk.length);
        }
      }
    }
  }

  function isPersonalEmail(email) {
    if (!email) return false;
    var personal = ['gmail.com','yahoo.com','hotmail.com','aol.com','outlook.com','icloud.com','comcast.net','live.com','msn.com','ymail.com','mail.com','protonmail.com','me.com','att.net','verizon.net','cox.net','sbcglobal.net','bellsouth.net','charter.net','earthlink.net'];
    var d = email.split('@')[1];
    return d ? personal.indexOf(d.toLowerCase()) !== -1 : false;
  }

  // ═══════════════════════════════════════════════════════════════════
  // FULL AUTOMATED SCRAPE PIPELINE
  // ═══════════════════════════════════════════════════════════════════
  function startScraping() {
    if (isScraping) { stopScraping(); return; }
    if (!activeListName) { alert('Create or select a list first!'); return; }
    var url = window.location.href;
    if (url.indexOf('/sales/search/people') === -1 && url.indexOf('/search/results/people') === -1) {
      alert('Go to a LinkedIn or Sales Navigator people search first.'); return;
    }
    isScraping = true; pageCount = 0; doneFirstPage = false;
    updateScrapeBtn();
    showStatus('Starting automated scrape...');
    doScrapePage();
  }

  function stopScraping() {
    isScraping = false;
    if (scrapeTimer) { clearTimeout(scrapeTimer); scrapeTimer = null; }
    if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
    updateScrapeBtn();
    showStatus('Scraping stopped. ' + getCount() + ' profiles captured. Starting enrichment...');
    // Auto-start enrichment after scraping stops
    setTimeout(function() { enrichAll(); }, 1000);
  }

  async function doScrapePage() {
    if (!isScraping) return;

    var cp = detectPage();
    if (cp > 0) pageCount = cp;
    updateStats();

    // Step 1: Scroll to load all profiles on page
    showStatus('Page ' + pageCount + ' — Scrolling to load profiles...');
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(3000);
    window.scrollTo(0, 0);
    await sleep(1000);
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(3000);

    if (!isScraping) return;

    // Step 2: Wait for profiles to arrive from interceptor
    showStatus('Page ' + pageCount + ' — Waiting for profiles...');
    await sleep(3000);

    if (!isScraping) return;

    var profiles = getProfiles();
    updateStats();

    showStatus('Page ' + pageCount + ' done — ' + getCount() + ' profiles captured');
    saveLists(); updateStats();
    await sleep(1000);

    // Step 3: Navigate to next page immediately (NO enrichment during scraping)
    goToNextPage();
  }

  function goToNextPage() {
    if (!isScraping) return;

    // Handle first page trick
    var cp = detectPage();
    if (cp === 2 && !doneFirstPage) {
      doneFirstPage = true;
      var prev = document.querySelector('button.search-results__pagination-previous-button') ||
                 document.querySelector('button.artdeco-pagination__button--previous');
      if (prev) { prev.click(); scrapeTimer = setTimeout(doScrapePage, 5000); return; }
    }

    // Find next button — try multiple selectors
    var url = window.location.href;
    var nextBtn = null, hasNext = false;

    if (url.indexOf('/sales/search/people') !== -1) {
      // Sales Navigator — try all known selectors
      nextBtn = document.querySelector('button.search-results__pagination-next-button') ||
                document.querySelector('button[aria-label="Next"]') ||
                document.querySelector('button[aria-label="next"]') ||
                document.querySelector('.search-results__pagination button:last-child') ||
                document.querySelector('li.search-results__pagination-list-item:last-child button');
      // Also try: find all pagination buttons, pick the one that says "Next" or ">"
      if (!nextBtn) {
        var allBtns = document.querySelectorAll('.search-results__pagination button, .artdeco-pagination button, nav[aria-label="Search results pagination"] button');
        for (var b = 0; b < allBtns.length; b++) {
          var txt = allBtns[b].textContent.trim().toLowerCase();
          var lbl = (allBtns[b].getAttribute('aria-label') || '').toLowerCase();
          if (txt === 'next' || txt === '›' || txt === '»' || lbl === 'next' || lbl.indexOf('next') !== -1) {
            nextBtn = allBtns[b]; break;
          }
        }
      }
      // Last resort: find the pagination container and get the last link/button
      if (!nextBtn) {
        var pagContainer = document.querySelector('.search-results__pagination') ||
                           document.querySelector('[class*="pagination"]') ||
                           document.querySelector('nav[aria-label*="pagination"]');
        if (pagContainer) {
          var links = pagContainer.querySelectorAll('button, a');
          for (var l = links.length - 1; l >= 0; l--) {
            var t = links[l].textContent.trim().toLowerCase();
            if (t === 'next' || t === '›' || t === '»') { nextBtn = links[l]; break; }
          }
        }
      }
      hasNext = nextBtn && !nextBtn.disabled && !nextBtn.classList.contains('disabled');
      console.log('[M365] Sales Nav next button:', nextBtn, 'hasNext:', hasNext);
    } else {
      // Regular LinkedIn
      nextBtn = document.querySelector('button.artdeco-pagination__button--next');
      hasNext = nextBtn && !nextBtn.disabled && !nextBtn.classList.contains('artdeco-button--disabled');
    }

    // FALLBACK: If no button found, try URL manipulation
    if (!hasNext && !nextBtn) {
      var currentPage = detectPage();
      console.log('[M365] No next button found. Current page:', currentPage, '. Trying URL-based navigation...');
      
      // Try clicking the next page number directly
      var nextPageNum = currentPage + 1;
      var pageButtons = document.querySelectorAll('.search-results__pagination-list button, .artdeco-pagination__pages button, [class*="pagination"] button, [class*="pagination"] a');
      for (var p = 0; p < pageButtons.length; p++) {
        if (parseInt(pageButtons[p].textContent.trim()) === nextPageNum) {
          nextBtn = pageButtons[p];
          hasNext = true;
          console.log('[M365] Found page ' + nextPageNum + ' button via number match');
          break;
        }
      }
    }

    // Debug: log all pagination elements
    if (!hasNext) {
      console.log('[M365] DEBUG - All pagination elements on page:');
      var allPag = document.querySelectorAll('[class*="pagination"], [aria-label*="pagination"], [aria-label*="Pagination"]');
      allPag.forEach(function(el) { console.log('[M365]  -', el.tagName, el.className, el.innerHTML.substring(0, 200)); });
    }

    if (hasNext && nextBtn) {
      var waitSec = Math.floor(Math.random() * 10) + 8;
      nextActionSec = waitSec;
      showStatus('Moving to next page in ' + waitSec + 's...');

      if (countdownTimer) clearInterval(countdownTimer);
      countdownTimer = setInterval(function () {
        nextActionSec = Math.max(0, nextActionSec - 1);
        var el = document.getElementById('m365-cd');
        if (el) el.textContent = nextActionSec;
        showStatus('Next page in ' + nextActionSec + 's | ' + getCount() + ' profiles, ' + getEmailCount() + ' emails');
      }, 1000);

      scrapeTimer = setTimeout(function () {
        if (!isScraping) return;
        if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
        pageCount++;
        window.scrollTo(0, 0);
        showStatus('Navigating to page ' + pageCount + '...');
        nextBtn.click();
        scrapeTimer = setTimeout(doScrapePage, 5000 + Math.random() * 3000);
      }, waitSec * 1000);
    } else {
      isScraping = false;
      if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
      showStatus('Scraping done! ' + getCount() + ' profiles across ' + pageCount + ' pages. Starting enrichment...');
      updateScrapeBtn();
      // Auto-start enrichment
      setTimeout(function() { enrichAll(); }, 1000);
    }
  }

  function detectPage() {
    var el;
    el = document.querySelector('li.search-results__pagination-list-item--active button');
    if (el) return parseInt(el.textContent.trim()) || 0;
    el = document.querySelector('ul.artdeco-pagination__pages--number li.selected button');
    if (el) return parseInt(el.textContent.trim()) || 0;
    el = document.querySelector('li.artdeco-pagination__indicator--number.active button');
    if (el) return parseInt(el.textContent.trim()) || 0;
    return 0;
  }

  // ─── Enrich All Profiles (runs after scraping) ────────────────────────
  async function enrichAll() {
    if (isEnriching || !activeListName) return;
    isEnriching = true; updateEnrichBtn();
    var total = getCount();

    // Step 1: Clearbit domain lookup
    showStatus('Enriching: Step 1/2 — Finding company domains (' + total + ' profiles)...');
    console.log('[M365] Looking up ' + total + ' company domains...');
    await lookupDomains();
    saveLists(); updateStats();

    // Step 2: Enrich via backend one-by-one (reliable)
    var toEnrich = Object.values(getProfiles()).filter(function (p) {
      if (!p.user_first_name || !p.user_company_name) return false;
      if (p.enriched_at) return false;
      if (!p.email_first) return true;
      return false;
    });

    if (toEnrich.length > 0) {
      showStatus('Enriching: Step 2/2 — SMTP verifying ' + toEnrich.length + ' profiles...');
      console.log('[M365] Enriching ' + toEnrich.length + ' profiles one-by-one...');
      for (var j = 0; j < toEnrich.length; j++) {
        await enrichViaBackend(toEnrich[j]);
        if (j % 3 === 0) { saveLists(); updateStats(); }
        showStatus('Enriching: ' + (j + 1) + '/' + toEnrich.length + ' | ' + getEmailCount() + ' emails found');
      }
    }

    saveLists(); isEnriching = false;
    updateStats(); updateEnrichBtn();
    showStatus('Done! ' + getEmailCount() + ' verified emails from ' + getCount() + ' profiles.');
    console.log('[M365] Done! ' + getEmailCount() + ' verified emails from ' + getCount() + ' profiles.');
  }

  // ─── CSV Export ─────────────────────────────────────────────────────
  function exportCSV(mode) {
    var profiles = Object.values(getProfiles());
    if (mode === 'email') profiles = profiles.filter(function (p) { return p.email_first; });
    else if (mode === 'noemail') profiles = profiles.filter(function (p) { return !p.email_first; });
    if (profiles.length === 0) { showStatus('No profiles to export.'); return; }
    var h = ['Email', 'Email 2', 'Phone', 'Company Phone', 'First Name', 'Last Name', 'Job Title', 'Company', 'Company Domain', 'Industry', 'City', 'LinkedIn URL', 'Confidence', 'Method', 'LinkedIn ID'];
    var csv = h.join(',') + '\n';
    profiles.forEach(function (p) {
      csv += [esc(p.email_first), esc(p.email_second), esc(p.phone), esc(p.company_phone), esc(p.user_first_name), esc(p.user_last_name), esc(p.job_title), esc(p.user_company_name), esc(p.company_domain), esc(p.industry), esc(p.user_city), esc(p.user_url), p.email_confidence || '', esc(p.email_method), esc(p.linkedin_id)].join(',') + '\n';
    });
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'm365_' + (activeListName || 'export').replace(/[^a-z0-9]/gi, '_') + '_' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    showStatus('Exported ' + profiles.length + ' profiles.');
  }
  function esc(s) {
    if (!s) return '';
    s = '' + s;
    return (s.indexOf(',') > -1 || s.indexOf('"') > -1 || s.indexOf('\n') > -1) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // ─── UI ─────────────────────────────────────────────────────────────
  function createUI() {
    if (panel || window.location.href.indexOf('linkedin.com') === -1) return;
    panel = document.createElement('div');
    panel.id = 'm365-panel';
    panel.innerHTML = [
      '<div class="m365-hdr">',
      '  <span class="m365-logo">\u26A1 ColdPumper</span>',
      '  <span class="m365-ver">v' + CONFIG.VERSION + '</span>',
      '  <button class="m365-mbtn" id="m365-min">\u2014</button>',
      '</div>',
      '<div id="m365-body">',
      '  <div class="m365-stats">',
      '    <div class="m365-st"><div class="m365-stn" id="m365-n-total">0</div><div class="m365-stl">PROFILES</div></div>',
      '    <div class="m365-st"><div class="m365-stn" id="m365-n-emails">0</div><div class="m365-stl">EMAILS FOUND</div></div>',
      '  </div>',
      '  <div class="m365-sec">',
      '    <div class="m365-sh">\uD83D\uDCCB LISTS</div>',
      '    <div class="m365-row"><select id="m365-sel" class="m365-select"></select>',
      '      <button class="m365-ib" id="m365-new-btn" title="New List">+</button>',
      '      <button class="m365-ib m365-ib-r" id="m365-del-btn" title="Delete">\uD83D\uDDD1</button>',
      '    </div>',
      '    <div id="m365-newrow" class="m365-row" style="display:none;margin-top:6px;">',
      '      <input type="text" id="m365-newname" class="m365-inp" placeholder="List name...">',
      '      <button class="m365-btn m365-btn-p" id="m365-create-btn">Create</button>',
      '      <button class="m365-btn" id="m365-cancel-btn">X</button>',
      '    </div>',
      '  </div>',
      '  <div class="m365-sec">',
      '    <div class="m365-sh">\uD83D\uDD0D AUTOMATED SCRAPE + ENRICH</div>',
      '    <div class="m365-info">Type: <b id="m365-stype">\u2014</b><br>Page: <b id="m365-spage">0</b> | Profiles: <b id="m365-sext">0</b> | Emails: <b id="m365-semails">0</b><br>Next: <b id="m365-cd">0</b>s</div>',
      '    <button class="m365-btn m365-btn-scrape m365-full" id="m365-scrape-btn">\u25B6 Start Scraping This Search</button>',
      '    <div class="m365-pipeline-note">Scrapes profiles \u2192 fetches LinkedIn emails \u2192 enriches via backend \u2192 moves to next page automatically</div>',
      '  </div>',
      '  <div class="m365-sec">',
      '    <div class="m365-sh">\uD83D\uDCE7 MANUAL ENRICH (single page)</div>',
      '    <button class="m365-btn m365-btn-enrich m365-full" id="m365-enrich-btn">\uD83D\uDD0D Enrich All (Find Emails)</button>',
      '  </div>',
      '  <div class="m365-sec">',
      '    <div class="m365-sh">\uD83D\uDCE5 DOWNLOAD CSV</div>',
      '    <div class="m365-row">',
      '      <button class="m365-btn m365-btn-csv" id="m365-csv-all">All</button>',
      '      <button class="m365-btn m365-btn-csv" id="m365-csv-em">With Email</button>',
      '      <button class="m365-btn m365-btn-csv" id="m365-csv-no">No Email</button>',
      '    </div>',
      '  </div>',
      '  <div class="m365-sec" id="m365-settings" style="display:none;">',
      '    <div class="m365-sh">\u2699\uFE0F SETTINGS</div>',
      '    <div class="m365-row" style="margin-bottom:6px;">',
      '      <input type="text" id="m365-api-inp" class="m365-inp" value="' + CONFIG.API_BASE + '">',
      '      <button class="m365-btn m365-btn-p" id="m365-api-sav">Save</button>',
      '    </div>',
      '    <button class="m365-btn" id="m365-api-tst" style="width:100%">Test Backend</button>',
      '    <div class="m365-sh" style="margin-top:10px;">\uD83D\uDD11 API KEYS (optional — uses your credits)</div>',
      '    <div style="font-size:10px;color:#999;margin-bottom:6px;">Leave blank to skip. Results are cached permanently.</div>',
      '    <div style="margin-bottom:4px;"><label style="font-size:10px;color:#aaa;">Apollo.io</label><input type="text" id="m365-key-apollo" class="m365-inp" placeholder="Your Apollo API key" style="width:100%;margin-top:2px;"></div>',
      '    <div style="margin-bottom:4px;"><label style="font-size:10px;color:#aaa;">Hunter.io</label><input type="text" id="m365-key-hunter" class="m365-inp" placeholder="Your Hunter API key" style="width:100%;margin-top:2px;"></div>',
      '    <div style="margin-bottom:4px;"><label style="font-size:10px;color:#aaa;">Snov.io (user_id:secret)</label><input type="text" id="m365-key-snov" class="m365-inp" placeholder="user_id:secret" style="width:100%;margin-top:2px;"></div>',
      '    <div style="margin-bottom:4px;"><label style="font-size:10px;color:#aaa;">RocketReach</label><input type="text" id="m365-key-rocketreach" class="m365-inp" placeholder="Your RocketReach API key" style="width:100%;margin-top:2px;"></div>',
      '    <button class="m365-btn m365-btn-p" id="m365-keys-sav" style="width:100%;margin-top:6px">\uD83D\uDCBE Save API Keys</button>',
      '    <button class="m365-btn m365-btn-d" id="m365-clear-btn" style="width:100%;margin-top:6px">Clear List Data</button>',
      '  </div>',
      '  <div class="m365-sts" id="m365-status">Ready</div>',
      '  <div class="m365-ft">',
      '    <button class="m365-lk" id="m365-set-tog">\u2699 Settings</button>',
      '    <span>ColdPumper by Grow Revenue Co.</span>',
      '  </div>',
      '</div>'
    ].join('\n');
    document.body.appendChild(panel);
    bindEvents();
    // Populate API key fields from saved values
    if (API_KEYS.apollo) byId('m365-key-apollo').value = API_KEYS.apollo;
    if (API_KEYS.hunter) byId('m365-key-hunter').value = API_KEYS.hunter;
    if (API_KEYS.snov) byId('m365-key-snov').value = API_KEYS.snov;
    if (API_KEYS.rocketreach) byId('m365-key-rocketreach').value = API_KEYS.rocketreach;
    refreshDropdown(); updateStats(); testBackend();
  }

  function bindEvents() {
    byId('m365-min').onclick = function () {
      var b = byId('m365-body'); var h = b.style.display === 'none';
      b.style.display = h ? 'block' : 'none'; this.textContent = h ? '\u2014' : '\u26A1';
    };
    byId('m365-new-btn').onclick = function () { byId('m365-newrow').style.display = 'flex'; byId('m365-newname').focus(); };
    byId('m365-create-btn').onclick = function () {
      var n = byId('m365-newname').value.trim();
      if (n && createList(n)) { byId('m365-newrow').style.display = 'none'; byId('m365-newname').value = ''; refreshDropdown(); updateStats(); showStatus('List "' + n + '" created.'); }
      else showStatus('List exists or empty.');
    };
    byId('m365-cancel-btn').onclick = function () { byId('m365-newrow').style.display = 'none'; };
    byId('m365-newname').onkeydown = function (e) { if (e.key === 'Enter') byId('m365-create-btn').click(); };
    byId('m365-sel').onchange = function () { switchList(this.value); };
    byId('m365-del-btn').onclick = function () {
      if (activeListName && confirm('Delete "' + activeListName + '"?')) { deleteList(activeListName); }
    };
    byId('m365-scrape-btn').onclick = function () { startScraping(); };
    byId('m365-enrich-btn').onclick = function () { enrichAll(); };
    byId('m365-csv-all').onclick = function () { exportCSV('all'); };
    byId('m365-csv-em').onclick = function () { exportCSV('email'); };
    byId('m365-csv-no').onclick = function () { exportCSV('noemail'); };
    byId('m365-set-tog').onclick = function () {
      var s = byId('m365-settings'); s.style.display = s.style.display === 'none' ? 'block' : 'none';
    };
    byId('m365-api-sav').onclick = function () {
      var u = byId('m365-api-inp').value.trim().replace(/\/$/, '');
      if (u) { CONFIG.API_BASE = u; chrome.storage.local.set({ m365_api_base: u }); showStatus('API saved.'); }
    };
    byId('m365-api-tst').onclick = function () { testBackend(); };
    byId('m365-keys-sav').onclick = function () {
      API_KEYS.apollo = (byId('m365-key-apollo').value || '').trim();
      API_KEYS.hunter = (byId('m365-key-hunter').value || '').trim();
      API_KEYS.snov = (byId('m365-key-snov').value || '').trim();
      API_KEYS.rocketreach = (byId('m365-key-rocketreach').value || '').trim();
      chrome.storage.local.set({ m365_api_keys: API_KEYS });
      var active = Object.keys(API_KEYS).filter(function(k) { return API_KEYS[k]; });
      showStatus('\uD83D\uDD11 API keys saved! Active: ' + (active.length > 0 ? active.join(', ') : 'none'));
    };
    byId('m365-clear-btn').onclick = function () {
      if (activeListName && lists[activeListName] && confirm('Clear "' + activeListName + '"?')) {
        lists[activeListName].profiles = {}; saveLists(); updateStats(); showStatus('Cleared.');
      }
    };
  }

  async function testBackend() {
    showStatus('Testing backend...');
    try {
      var r = await fetch(CONFIG.API_BASE + '/health', { signal: AbortSignal.timeout(8000) });
      if (r.ok) { var d = await r.json(); showStatus('\u2705 Backend connected! v' + (d.version || '?')); }
      else showStatus('\u274C Error ' + r.status);
    } catch (e) { showStatus('\u274C Backend: ' + (e.message || 'unreachable')); }
  }

  function byId(id) { return document.getElementById(id); }

  function refreshDropdown() {
    var sel = byId('m365-sel'); if (!sel) return;
    sel.innerHTML = '';
    var names = Object.keys(lists);
    if (names.length === 0) { sel.innerHTML = '<option value="">-- Create a list --</option>'; return; }
    names.forEach(function (n) {
      var c = Object.keys(lists[n].profiles).length;
      var o = document.createElement('option');
      o.value = n; o.textContent = n + ' (' + c + ')';
      if (n === activeListName) o.selected = true;
      sel.appendChild(o);
    });
  }

  function updateStats() {
    var t = byId('m365-n-total'); if (t) t.textContent = getCount();
    var e = byId('m365-n-emails'); if (e) e.textContent = getEmailCount();
    var p = byId('m365-spage'); if (p) p.textContent = pageCount;
    var x = byId('m365-sext'); if (x) x.textContent = getCount();
    var em = byId('m365-semails'); if (em) em.textContent = getEmailCount();
    refreshDropdown(); updateSearchType();
  }

  function updateSearchType() {
    var el = byId('m365-stype'); if (!el) return;
    var u = window.location.href;
    if (u.indexOf('/sales/search/people') !== -1) el.textContent = 'Sales Navigator';
    else if (u.indexOf('/search/results/people') !== -1) el.textContent = 'LinkedIn Search';
    else el.textContent = 'Not a search page';
  }

  function updateScrapeBtn() {
    var b = byId('m365-scrape-btn'); if (!b) return;
    if (isScraping) { b.textContent = '\u23F9 Stop Scraping'; b.className = 'm365-btn m365-btn-stop m365-full'; }
    else { b.textContent = '\u25B6 Start Scraping This Search'; b.className = 'm365-btn m365-btn-scrape m365-full'; }
  }

  function updateEnrichBtn() {
    var b = byId('m365-enrich-btn'); if (!b) return;
    if (isEnriching) { b.textContent = '\u23F3 Enriching...'; b.disabled = true; }
    else { b.textContent = '\uD83D\uDD0D Enrich All (Find Emails)'; b.disabled = false; }
  }

  function showStatus(msg) {
    var el = byId('m365-status'); if (el) el.textContent = msg;
    console.log('[M365] ' + msg);
  }

  // ─── Layer 4: LinkedIn Account Detection ──────────────────────────

  function detectLinkedInAccount() {
    try {
      // Sales Navigator: look for the profile photo link in nav
      var navLink = document.querySelector('a[href*="linkedin.com/in/"]');
      if (navLink) {
        chrome.runtime.sendMessage({ type: 'SET_LINKEDIN_ACCOUNT', url: navLink.href }).catch(function () {});
        return;
      }
      // Regular LinkedIn: try the "Me" dropdown link
      var meLink = document.querySelector('.global-nav__me a[href*="/in/"]');
      if (meLink) {
        chrome.runtime.sendMessage({ type: 'SET_LINKEDIN_ACCOUNT', url: meLink.href }).catch(function () {});
        return;
      }
      // Sales Nav: try the nav profile image container
      var salesNavProfile = document.querySelector('[data-test-global-nav-me-photo]');
      if (salesNavProfile) {
        var parentLink = salesNavProfile.closest('a');
        if (parentLink && parentLink.href.indexOf('/in/') !== -1) {
          chrome.runtime.sendMessage({ type: 'SET_LINKEDIN_ACCOUNT', url: parentLink.href }).catch(function () {});
        }
      }
    } catch (e) {}
  }

  // ─── License Gate ──────────────────────────────────────────────────

  function createLockedPanel() {
    if (byId('m365-panel')) return; // already exists
    var p = document.createElement('div');
    p.id = 'm365-panel';
    p.innerHTML = [
      '<div class="m365-hdr">',
      '  <span class="m365-logo">\u26A1 ColdPumper</span>',
      '  <span class="m365-ver">v' + CONFIG.VERSION + '</span>',
      '  <span class="m365-min" id="m365-min">\u2014</span>',
      '</div>',
      '<div id="m365-body">',
      '  <div class="m365-sec" style="text-align:center;padding:20px 10px;">',
      '    <div style="font-size:32px;margin-bottom:8px;">\uD83D\uDD12</div>',
      '    <div style="font-size:13px;color:#fff;font-weight:600;margin-bottom:6px;">License Required</div>',
      '    <div style="font-size:11px;color:#6b7280;line-height:1.5;margin-bottom:14px;">',
      '      Activate your ColdPumper license to start extracting emails from LinkedIn.',
      '    </div>',
      '    <div style="font-size:10px;color:#4b5563;">Click the extension icon \u2197 to activate</div>',
      '  </div>',
      '  <div class="m365-ft">',
      '    <span>ColdPumper by Grow Revenue Co.</span>',
      '  </div>',
      '</div>'
    ].join('\n');
    document.body.appendChild(p);
    byId('m365-min').onclick = function () {
      var b = byId('m365-body'); var h = b.style.display === 'none';
      b.style.display = h ? 'block' : 'none'; this.textContent = h ? '\u2014' : '\u26A1';
    };
  }

  function removePanel() {
    var p = byId('m365-panel');
    if (p) p.remove();
    panel = null;
  }

  // ─── License message listeners ─────────────────────────────────────

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg.type === 'LICENSE_ACTIVATED') {
      removePanel();
      loadData(function () { createUI(); });
    }
    if (msg.type === 'LICENSE_DEACTIVATED') {
      removePanel();
      isScraping = false; isEnriching = false;
      if (scrapeTimer) { clearTimeout(scrapeTimer); scrapeTimer = null; }
      if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
      createLockedPanel();
    }
  });

  // ─── Init ───────────────────────────────────────────────────────────
  function init() {
    if (window.location.href.indexOf('linkedin.com') === -1) return;

    // Check license via background service worker
    chrome.runtime.sendMessage({ type: 'CHECK_LICENSE' }, function (resp) {
      if (chrome.runtime.lastError || !resp) {
        // Background not responding — check storage directly
        chrome.storage.local.get(['cp_license_valid', 'cp_license_key', 'cp_is_owner'], function (data) {
          var ownerKey = 'CP-OWNER-GROWREVENUE-2026-UNLIMITED';
          var licensed = (data.cp_license_key === ownerKey && data.cp_is_owner) ||
                         (data.cp_license_valid === true && !!data.cp_license_key);
          if (licensed) {
            loadData(function () {
              if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', createUI);
              else createUI();
              setTimeout(detectLinkedInAccount, 3000);
            });
          } else {
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', createLockedPanel);
            else createLockedPanel();
          }
        });
        return;
      }
      if (resp && resp.licensed) {
        loadData(function () {
          if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', createUI);
          else createUI();
          // Layer 4: Detect and report LinkedIn account
          setTimeout(detectLinkedInAccount, 3000);
        });
      } else {
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', createLockedPanel);
        else createLockedPanel();
      }
    });

    setInterval(updateSearchType, 3000);
  }
  init();
})();
